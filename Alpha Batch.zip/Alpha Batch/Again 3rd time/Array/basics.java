import java.util.*;

public class basics{
    public static void main(String[] args) {
        int arr[]= new int[100];

        Scanner sc = new Scanner(System.in);
        
        // System.out.println("Enter marks of Physics");
        // arr[0] = sc.nextInt();
        // System.out.println("Enter marks of Chemistry");
        // arr[1] = sc.nextInt();
        // System.out.println("Enter marks of Maths");
        // arr[2] = sc.nextInt();

        // System.out.println("Physics " + arr[0] + " Chemistry " + arr[1] + " Maths " + arr[2]);

        System.out.println(arr.length);

    }
}