public class basics2 {

    public static void update(int arr[]){

        for(int i=0; i<arr.length; i++){
            arr[i] = arr[i]+10;
        }
    }
    public static void main(String[] args) {
        
        int arr[] = {5 ,10 , 15};

        update(arr);

        //printing the array
        for(int i=0; i<arr.length;i++){
            System.out.print(arr[i] + "  ");
        }
        System.out.println();
    }
}
