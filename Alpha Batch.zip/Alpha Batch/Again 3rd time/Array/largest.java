public class largest {

    public static int large(int number[]){
        int no = Integer.MIN_VALUE;

        for(int i=0; i<number.length; i++){
            if(no < number[i]){
                no = number[i];
            }
        }
        return no;

    }
    public static void main(String[] args) {
        int number[] = { 1 , 4 , 8, 12 , 16 , 11 , 2, 4 , 6};

        int lar = large(number);

        System.out.println("Largest Number is : " + lar);
        
    }
}
