public class linearSearch {

    public static int linear(int no[], int key){

        for(int i=0; i<no.length; i++){
            if(no[i] == key){
                return i;
            }
        }
        return -1;

    }
    public static void main(String[] args) {
        
        int no[] = {5, 6 , 7 , 8 , 10};

        int ans = linear(no, 10);
        
        if(ans == -1){
            System.out.println("NOT FOUND");
        }else{
            System.out.println("Found at : " + ans);
        }
    }
}
