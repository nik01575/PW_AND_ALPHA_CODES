import java.util.*;

public class helloWorld
{
    public static void main(String[]args)
    {
        // Scanner sc = new Scanner(System.in);
        // int a = sc.nextInt();
        // int b = sc.nextInt();
        // System.out.println("the output is : " + (a+b));

        // Scanner sc1 = new Scanner(System.in);
        // String str = sc1.next();
        // System.out.println(str);

        // Scanner sc1 = new Scanner(System.in);
        // System.out.println("Enter the sentence");
        // String str = sc1.nextLine();
        // System.out.println(str);

    
    }
}