public class ifelse
{
    public static void main(String[] args) {
        if(10<2)
        {
            System.out.println("10 is greater than 2");
        }else{
            System.out.println("10 is lesser than 2");
        }
    }
}