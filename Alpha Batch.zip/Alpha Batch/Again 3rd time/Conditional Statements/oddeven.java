public class oddeven {
    public static void main(String[] args) {
        int a=41;

        if(a%2==0){
            System.out.println(a + " is Even");
        }else{
            System.out.println("odd no");
        }
    }
}
