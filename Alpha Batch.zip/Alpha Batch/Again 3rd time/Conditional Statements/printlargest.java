public class printlargest
{
    public static void main(String[] args) {
        int a = 1;
        int b=1;

        if(a>b){
            System.out.println("Largest Value is : " + a);
        }else if(a==b)
        {
            System.out.println(" A and B are equal");
        }
        else{
            System.out.println("Largest Value is : " + b);
        }
    }
}