public class basic{

    // public static void print(){
    //     System.out.println("Hello World");
    // }

    public static int sum(int a , int b){
        int result = a+b;
        return result;
    }
    public static void main(String[] args) {
        // print();
        
        System.out.println(sum(10, 5));
    }
}