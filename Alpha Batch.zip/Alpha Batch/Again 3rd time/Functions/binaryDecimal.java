public class binaryDecimal {

    public static void decToBin(int binNo){
        int myNo = binNo;
        int pow = 0;
        int decNo = 0;

        while (binNo > 0) {
            int lastDigit = binNo % 10;

            decNo = decNo + (lastDigit * (int)Math.pow(2, pow));

            pow++;
            binNo = binNo/10;
        }

        System.out.println("Decimal of "+ myNo + " is " + decNo);
    }
    public static void main(String[] args) {
        decToBin(101);
    }
}
