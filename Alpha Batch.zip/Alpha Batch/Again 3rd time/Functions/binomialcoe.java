public class binomialcoe {

    public static int factorial(int n){
        int f =1;

        for(int i=1;i<=n; i++){
            f = f*i;
        }
        return f;
    }

    public static int bin_coe(int n, int r){

        return factorial(n)/(factorial(r)*factorial(n-r));
        
    }
    public static void main(String[] args) {

        System.out.println(bin_coe(5, 2));
    }
}
