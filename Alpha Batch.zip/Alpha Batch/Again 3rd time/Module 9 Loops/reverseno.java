import java.util.*;
public class reverseno {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number");
        int n = sc.nextInt();
        System.out.println("Your entered number is " + n);

        while(n>0){
            System.out.print(n%10);
            n = n/10;
        }



    }
}
