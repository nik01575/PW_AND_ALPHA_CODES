public class whileloop{
    public static void main(String[] args) {
        int count = 1;

        while(count <= 10)
        {
            System.out.println(count);
            count++;
        }
    }
}