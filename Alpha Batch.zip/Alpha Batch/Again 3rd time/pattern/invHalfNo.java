public class invHalfNo {
    public static void main(String[] args) {
        
        int row = 4;
        int col = 4;
        int no = 1;

        for(int i =0; i<=row; i++){
            for(int j=0; j<=col; j++){
                if(i + j > col){
                    System.out.print("   ");
                } else {
                    System.out.print(" " + no + " ");
                }
            }
            System.out.println();
        }
    }
}
