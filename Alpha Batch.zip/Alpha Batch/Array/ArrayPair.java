public class ArrayPair {

    public static void Pair(int num[])
    {
        int tp=0;
        for(int i=0; i<num.length; i++)
        {
            int start = num[i];

            for(int j =i+1; j<num.length; j++)
            {
                System.out.print( "("+ start +"," + num[j] + ")");
                tp++;
            }
            
            System.out.println();
        }
        System.out.println("Your Total Pairs : "+tp);
    }
    public static void main(String[] args) {
        
        int num []= {2 , 4 , 6, 8 , 10 , 12, 14};
        Pair(num);
    } 
}
