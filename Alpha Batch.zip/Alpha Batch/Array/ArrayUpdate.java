import java.util.*;

public class ArrayUpdate {

    public static void ArrayUpdate(int marks[])
    {
        for(int i = 0; i<marks.length; i++)
        {
            marks[i] = marks[i] + 1;
        }
    }
    public static void main(String[] args) {
        
        int marks[] = {55 ,  66 , 26};

        ArrayUpdate(marks);

        for(int i = 0; i<marks.length; i++)
        {
            System.out.print(marks[i] + " ");
        }

        System.out.println();

    }
}
