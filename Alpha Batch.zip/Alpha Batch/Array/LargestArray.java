import java.util.*;
public class LargestArray {

    public static int Largest(int number[])
    {
        int high= Integer.MIN_VALUE;
        int small = Integer.MAX_VALUE;

        for(int i =0 ; i< number.length ; i++)
        {
            if(high<number[i])
            {
                high = number[i];
            }
            if(small>number[i])
            {
                small = number[i];
            }
        }

        System.out.println( "Smallest Value Is:  " + small);
        return high;
    }
    public static void main(String[] args) {
        
        int number[] = {32 ,7,  89, 78 , 43 , 112 ,90 , 98};

        System.out.println("Largest Value Is:  " + Largest(number));
        
    }
}
