import java.util.*;

public class Launch
{
    public static void main(String[] args) {
        
        int Students[] = new int[50];
        // int a;
        Scanner sc = new Scanner(System.in);
        Students[0] = sc.nextInt();
        Students[1] = sc.nextInt();
        Students[2] = sc.nextInt();
        Students[3] = sc.nextInt();

        Arrays.sort(Students);

        
    }

    {
        // int marks[] = {5, 10, 15, 20 , 25};
        // int age[] = { 2 , 4, 6, 8, 10};

        // System.out.println(Students[3]);
        // // System.out.println(age);

        // Students[3] = 99;
        // System.out.println(Students[3]);
    }
}