public class LinearSearch {

    public static int Search(int numbers[] , int key)
    {
        for(int i=0 ; i<numbers.length; i++)
        {
            if(numbers[i]==key)
            {
                return i;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        
        int numbers[] = {36 ,75 , 46 , 25 , 22};
        int key = 25;

        int index = Search(numbers , key);

        if(index== -1)
        {
            System.out.println("Not Found");
        }
        else{
            System.out.println("Number is Found at Index:  " + index);
        }
    }
}
