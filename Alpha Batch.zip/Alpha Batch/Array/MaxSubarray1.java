public class MaxSubarray1 {

    public static void Print(int num[])
    {
        int curSum=0;
        int max = Integer.MIN_VALUE;
        for(int i=0; i<num.length; i++)
        {
            int start=i;

            for(int j =i; j<num.length; j++)
            {
                int end =j;
                curSum=0;
                for(int k=start ; k<= end ; k++)
                {
                    curSum+=num[k];
                }
                System.out.println(curSum);
                if(max < curSum)
                {
                    max=curSum;
                }
            }
            
        }
        System.out.println("Your Total Subarray : "+curSum);
    }
    public static void main(String[] args) {
        
        int num []= {2 , 4 , 6, 8 , 10 , 12, 14};
        Print(num);
    } 
}
