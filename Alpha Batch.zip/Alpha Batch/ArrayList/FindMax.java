import java.util.*;

public class FindMax {
    public static void main(String[] args) {
        
        ArrayList<Integer> arr = new ArrayList<>();
        arr.add(55);
        arr.add(33);
        arr.add(563);
        arr.add(31);
        arr.add(50);

        int max = Integer.MIN_VALUE;

        for(int i =0;i<arr.size(); i++)
        {
            // if(max<arr.get(i))
            // {
            //     max = arr.get(i);
            // }

            max = Math.max(max, arr.get(i));
        }
        System.out.println("Maximum No " + max);
    }
}
