import java.util.*;

public class PrintSum3 {

    public static boolean sum(ArrayList<Integer> height, int target) {
        int pivot = -1;
        for (int i = 0; i < height.size(); i++) {
            if (height.get(i) > height.get(i + 1)) {
                pivot = i;
                break;
            }
        }
        int rp = pivot;
        int lp = pivot + 1;
        int n = height.size();

        while(lp!=rp)
        {
            // case1
            if (height.get(lp) + height.get(rp) == target) {
                return true;
            }

            // case2
            if (height.get(lp) + height.get(rp) < target) {
                lp = (lp+1)%n;
            }

            // case3
            else {
                rp = (n+rp-1)%n;
            }
        }
        return false;

    }

    public static void main(String[] args) {

        ArrayList<Integer> height = new ArrayList<>();
        height.add(11);
        height.add(15);
        height.add(6);
        height.add(8);
        height.add(9);
        height.add(10);

        int target = 17;

        System.out.println(sum(height, target));
    }
}
