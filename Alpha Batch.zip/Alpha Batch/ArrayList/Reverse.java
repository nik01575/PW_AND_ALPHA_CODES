import java.util.*;

public class Reverse {
    public static void main(String[] args) {
        
        ArrayList<Integer> arr = new ArrayList<>();
        arr.add(55);
        arr.add(33);
        arr.add(563);
        arr.add(31);
        arr.add(50);

        for(int i = arr.size()-1 ; i>=0 ; i--)
        {
            System.out.print(arr.get(i) + " ");
        }
        System.out.println();
    }
}
