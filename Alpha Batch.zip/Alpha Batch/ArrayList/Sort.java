import java.util.*;
public class Sort {
    public static void main(String[] args) {
        
        ArrayList<Integer> arr = new ArrayList<>();
        arr.add(2);
        arr.add(5);
        arr.add(9);
        arr.add(3);
        arr.add(6);

        System.out.println(arr);
        Collections.sort(arr);   //Sorting in Ascending Order
        System.out.println(arr);     

        Collections.sort(arr, Collections.reverseOrder()); //Sorting in Descending order
        System.out.println(arr);
    }
}
