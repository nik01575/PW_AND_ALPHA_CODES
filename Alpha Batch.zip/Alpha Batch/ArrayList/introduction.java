import java.util.*;

public class introduction
{
    public static void main(String[] args) {
        
        ArrayList<Integer> arr = new ArrayList<>();
        arr.add(55);
        arr.add(33);
        arr.add(563);
        arr.add(31);
        arr.add(50);

        System.out.println("Art index 2 " + arr.get(2));

        arr.add(2, 9);
        System.out.println("Art index 2 " + arr.get(2));
        arr.remove(0);
        System.out.println("Art index 2 " + arr.get(0));
        
        System.out.println(arr.contains(50)); 

        for(int i =0; i<arr.size(); i++)
        {
            System.out.print("[" + arr.get(i) + "]");
        }


        
        
    }
}