import java.util.*;

public class swap {
    public static void main(String[] args) {

        ArrayList<Integer> arr = new ArrayList<>();
        arr.add(2);
        arr.add(5);
        arr.add(9);
        arr.add(3);
        arr.add(6);

        System.out.println("Before Change");
        System.out.println(arr);

        System.out.println();
        System.out.println("After Change");
        System.out.println(arr);

        int temp = arr.get(1);
        arr.set(1, arr.get(3));
        arr.set(3, temp);


    }
}
