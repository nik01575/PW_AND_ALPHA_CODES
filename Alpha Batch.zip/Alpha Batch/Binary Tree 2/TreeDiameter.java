public class TreeDiameter {
    
    static class Node {
        int data;
        Node left;
        Node right;

        Node(int data) {
            this.data = data;
            this.right = null;
            this.left = null;
        }
    }

    public static int height(Node root)
    {
        if(root == null)
        {
            return 0;
        }

        int leftHeight = height(root.left);
        int rightHeight = height(root.right);
        return Math.max(leftHeight , rightHeight) + 1;
    }

    //Time Complexity = 0(n^2)
    public static int Diameter(Node root)
    {
        if(root == null)
        {
            return 0;
        }

        int left_dia = Diameter(root.left);
        int left_ht = height(root.left);
        int right_dia = Diameter(root.left);
        int right_ht = height(root.right);

        int self_Dia = left_ht + right_ht + 1;

        return Math.max(self_Dia , Math.max(left_dia, right_dia));
    }

    //Advanced Code for Diameter , Time Complexity = 0(n);

    static class Info
    {
        int dia; 
        int hei;
        public Info(int dia , int hei)
        {
            this.dia = dia;
            this.hei = hei;
        }
    }
    public static Info Adv_Diameter(Node root)
    {
        if(root == null)
        {
            return new Info(0, 0);
        }
        Info left_info = Adv_Diameter(root.left);
        Info right_info = Adv_Diameter(root.right);

        int diam = Math.max(Math.max(left_info.dia, right_info.dia), left_info.hei + right_info.hei + 1);

        int hei = Math.max(left_info.hei, right_info.hei ) + 1;

        return new Info(diam, hei);

    }

   
    public static void main(String[] args) {
        Node root = new Node(1);
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.right.left = new Node(6);
        root.right.right = new Node(7);

        // System.out.println(Diameter(root));
        System.out.println(Adv_Diameter(root).dia);
    }
}
