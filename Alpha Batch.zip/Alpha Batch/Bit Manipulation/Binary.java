public class Binary
{
    public static void main(String[] args) {
        System.out.println((5 & 6));    //Binary And
        System.out.println((5 | 6));    //Binary Or
        System.out.println((5 ^ 6));    //Binary Xor
        System.out.println((~5));    //Negation
        System.out.println((5 << 2));    //Binary Left Shift
        System.out.println((6 >> 1));    //Binary Right Shift
    }
}