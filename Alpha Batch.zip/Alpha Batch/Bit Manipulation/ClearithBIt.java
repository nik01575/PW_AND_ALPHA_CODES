public class ClearithBIt {

    public static int clearbit(int n , int key)
    {
        int bitmask = ~(1<<key);
        return n & bitmask;
    }
    public static int updateithbit(int n , int key , int newbit)
    {
        n = clearbit(n, key);
        int bitmask = newbit<<key;
        return n| bitmask;
    }
    public static void main(String[] args) {
        System.out.println(clearbit(10, 1));

        System.out.println(updateithbit(10 , 2 ,1));
    }
}