public class GetithBit {
    public static int getbit(int n , int key)
    {
        int bitmask = 1<<key;
        if((n & bitmask) == 0)
        {
            return 0;
        }
        else{
            return 1;
        }
    }
    public static void main(String[] args) {
    
        System.out.println(getbit(10, 2));

        //10-------------1010
        //2--------------10
        //1<<2-----------0000

        //10 & 1<<2 -----0000


        //10-------------1010
        //3--------------0011
        //1<<3-----------0000

        //10 & 1<<3 -----0000

    }
}
