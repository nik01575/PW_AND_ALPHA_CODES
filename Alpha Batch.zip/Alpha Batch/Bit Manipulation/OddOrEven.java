import java.util.*;
class OddOrEven {

    public static void CheckOddEven(int a) {
        int bitmask = 1;
        if ((a & bitmask) == 0) {
            System.out.println("Even");
        } else {
            System.out.println("Odd");
        }
    }

    public static void main(String[] args) {
        CheckOddEven(3);
        CheckOddEven(5);
        CheckOddEven(6);
        CheckOddEven(11);

    }
}
