public class PowerOfTwo {

    public static boolean isPowerOfTwo(int n)
    {
        return (n & (n-1)) == 0;
    }
    public static void main(String[] args) {
        boolean result  = isPowerOfTwo(31);

        if(result == true)
        {
            System.out.println("Power Of 2");
        }
        else{
            System.out.println("Not Power Of 2");
        }
    } 
}
