public class Solution{
    public static void main(String[]args) {
        int x=3,y=4;
        System.out.println("Before swap: x = " + x + " and y = " + y);

         System.out.println(x = x^y);
         System.out.println(y = x^y);
         System.out.println(x = x^y);

        System.out.println("After swap: x = "+ x +" and y = " + y);
    }
    }
