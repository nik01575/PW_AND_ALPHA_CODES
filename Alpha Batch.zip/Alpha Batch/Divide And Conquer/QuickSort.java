public class QuickSort {
    
    public static void sort(int arr[], int start, int end)
    {
        if(start >= end)
        {
            return;
        }

        int partion_indx = partition(arr , start , end);
        sort(arr, start, partion_indx-1); // left
        sort(arr, partion_indx + 1, end); // right
        
    }

    public static int partition(int arr[], int start, int end)
    {
        int pivot = arr[end];
        int i = start-1;

        for(int j=start; j<end; j++)
        {
            if(arr[j]<=pivot)
            {
                i++;
                //swap
                int temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }
        }
        i++;
                //swap
                int temp = pivot;
                arr[end] = arr[i];
                arr[i] = temp;

        return i;
    }
    public static void main(String[] args) {
        int arr[] = { 4, 2, 6, 7, 10, 8, 20, 16, 21 , -2 , 0};
        sort(arr, 0, arr.length-1);

        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + "  ");
        }
    }
}
