
public class BtoD {

    public static void Bin(int bin)
{
    int myno= bin;
    int p = 0;
    int deci =0;
    
    while(bin>0)
    {
        int lastdigit = bin % 10;
        deci = deci + ( lastdigit * (int)Math.pow(2, p));

        p ++ ;
        bin = bin/10;
    }
    System.out.println("Decimal Of " + myno + " = " + deci);
}
    public static void main(String[] args) {
        
        Bin(101);
    }
}
