public class basic
{
    static void hello()        //parameters
    {
        System.out.println("Hello World");
        System.out.println("Hello World");
        System.out.println("Hello World");
    }

    public static int sum(int a , int b, int c)
    {
        System.out.println(a+b+c);
        return a+b+c ;
    }
    public static void main(String[] args) {
        
        // hello();
    
        sum(5,10,5);     // arguments
        sum(15,100,35);
        sum(50,100,50);
       
    }

}