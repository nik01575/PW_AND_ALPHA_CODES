public class bcoe {
    public static int nfac(int a)
    {
        int f = 1;

        for(int i = 1 ; i<= a ; i++)
        {
            f = f*i;
        }
        return f;
    }
    public static int rfac(int b)
    {
        int g = 1;

        for(int i = 1 ; i<= b ; i++)
        {
            g = g*i;
        }
        return g;
    }
    
    public static int nmrfac(int a , int b)
    {
        int h = a-b;
        int j = 1;

        for(int i = 1 ; i<= h ; i++)
        {
            j = j*i;
        }
        return j;
    }
    public static void main(String[] args) {
     
        System.out.println( "N factorial is : " + nfac(5));
        System.out.println( "R factorial is : " +  rfac(2));
        System.out.println( "NMR factorila is : " +  nmrfac(5,2));

        int c = nfac(5);
        int v = rfac(2);
        int w = nmrfac(5,2);

        int n = c/ (v*w);
        System.out.println("Factorial is : " + n);

        
    }
}
