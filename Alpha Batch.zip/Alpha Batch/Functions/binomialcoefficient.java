public class binomialcoefficient {


    public static int fac(int a) {
        int f = 1;

        for (int i = 1; i <= a; i++) {
            f = f * i;
        }
        return f;
    }

    public static int binomialcoe(int n, int r) {
        int fact_n = fac(n);
        int fact_r = fac(r);
        int fact_nmr = fac(n-r);

        int bincoe = fact_n/(fact_r*fact_nmr);
        return bincoe;
    }

    public static void main(String[] args) {

        System.out.println("Your Factorial is : " + binomialcoe(5 , 2));
    }
}
