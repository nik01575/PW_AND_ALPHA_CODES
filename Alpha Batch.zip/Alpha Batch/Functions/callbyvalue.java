public class callbyvalue {

    public static void swap(int a , int b)
    {
        int temp =a;
        a = b;
        b = temp;

        System.out.println("The values of a is " + a);
        System.out.println("The values of b is " + b);
        return;
    }
    public static void main(String[] args) {

        //swapping

        int a = 10;
        int b = 100;
        swap(a, b);    //call by value
        
    
    }
}
