public class multiply {

    public static int mul(int a , int b)
    {
        int d = a*b;
        
        return d;
    }
    public static void main(String[] args) {
        
        int a = 5;
        int b = 10;

        int c = mul(a , b);
        System.out.println("The value is : " + c);
    }
}
