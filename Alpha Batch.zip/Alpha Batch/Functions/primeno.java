
public class primeno {

    // public static boolean primenum(int n )
    // {
    // boolean primenum=true;

    // for(int i =2; i<=n-1 ; i++)
    // {
    // if(n%i==0)
    // {
    // primenum = false;
    // break;
    // }

    // }
    // return primenum;
    // }
    public static boolean primenum(int n) // optimised code
    {
        if (n == 2) {
            return true;
        }

        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }

        }
        return true;

    }

    public static void PrimeRange(int n) {       //Prime Range
        for(int i =2; i<=n; i++)
        {
            if(primenum(i))
            {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {

        PrimeRange(13);
    }

}
