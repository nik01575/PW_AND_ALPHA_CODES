import java.util.*;

public class MinAbsoluteDifference {
    public static void main(String[] args) {
        
        int[] A= {1 , 3 , 2};
        int[] B= {3 , 1 , 2};

        Arrays.sort(A);
        Arrays.sort(B);

        int minAbs=0;

        for(int i=0 ; i<A.length ; i++)
        {
            minAbs = minAbs + Math.abs(A[i] - B[i]);
        }
        System.out.println("Minimum Absolute Difference is : " + minAbs);
    }
}
