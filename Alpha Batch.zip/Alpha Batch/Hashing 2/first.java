import java.util.HashMap;

public class first{
    public static void main(String[] args) {
        
        HashMap<String, Integer> hm = new HashMap<>();
        hm.put("india", 100);
        hm.put("china", 0);
        hm.put("indonesia", 102);

        
        System.out.println(hm.get("india"));
        System.out.println(hm);
        System.out.println(hm.containsKey("india"));
        System.out.println(hm.containsKey("pakistan"));
        hm.remove("india");
        System.out.println(hm);
        System.out.println(hm.size());
    }
}