import java.util.*;

public class second {
    public static void main(String[] args) {
        
        HashMap<String,Integer> hm = new HashMap<>();
        hm.put("India", 1);
        hm.put("SriLanka", 2);
        hm.put("Australia", 3);
        hm.put("New Zealand", 4);
        hm.put("Bhutan", 5);

        //Iterate
        Set<String> keys = hm.keySet();
        System.out.println(keys);

        for(String k : keys){
            System.out.println("Keys = " + k + " , Values = " + hm.get(k));
        }
    }
}
