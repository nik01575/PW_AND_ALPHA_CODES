import java.io.*;  
import java.util.*;

public class Iterator {
    public static void main(String[] args) {
        
        HashSet<String> cities = new HashSet<>( );
        cities.add("Delhi");
        cities.add("Mumbai");
        cities.add("Kolkata");
        cities.add("Kanpur");
        cities.add("Uttarakhand");

        // Iterator <String> it = cities.iterator();
        // while(it.hasNext())
        // {
        //     System.out.println(it.next());
        // }

        for(String city : cities)
        {
            System.out.println(city);
        }
    }
}
