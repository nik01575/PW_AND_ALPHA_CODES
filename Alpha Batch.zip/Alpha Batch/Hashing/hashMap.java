import java.util.*;

public class hashMap
{
    public static void main(String[] args) {
        //Create
        HashMap<String , Integer> hm = new HashMap<>();

        hm.put("India", 100);
        hm.put("Pakistan", 30);
        hm.put("US", 75);
        hm.put("Srilanka", 75);

        // System.out.println(hm);

        // int population = hm.get("US");

        // System.out.println(population);

        // System.out.println(hm.containsKey("India"));  //doesn't tell difference uppercase and lowercase

        // System.out.println(hm.remove("US"));
        // System.out.println(hm);

        // System.out.println(hm.size());

        // System.out.println(hm.isEmpty());

        //-----------------Iterate-----------

        Set<String> keys = hm.keySet();
        System.out.println(keys);

        for(String k: keys)
        {
            System.out.println("Keys : " + k + " ,  Values : " + hm.get(k));
        }
    }
}