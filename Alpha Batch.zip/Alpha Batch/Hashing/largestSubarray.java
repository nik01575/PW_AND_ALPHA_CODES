import java.util.HashMap;

public class largestSubarray {
    public static void main(String[] args) {
        int arr[] = {15 , -2 , 2 ,-8 , 1, 7 , 10 , 23};
        int count = 0;

        HashMap<Integer , Integer> map = new HashMap<>();
        //sum, indx
        int sum=0; 
        int length =0;

        for(int j=0; j<arr.length; j++)
        {
            sum = sum + arr[j];
            if(map.containsKey(sum))
            {
                length = Math.max(length, j-map.get(sum));
            }else{
                map.put(sum,j);
            }
        }
        System.out.println("Largest Subarray with sum is " + length);



        // for(int i=0; i<arr.length; i++)
        // {
        //     for(int j=i+1; j<arr.length; j++)
        //     {
        //         if(arr[i]+arr[j] == 0)
        //         {
        //             count++;
        //         }
        //     }
        // }
        // System.out.println(count);
    } 
}
