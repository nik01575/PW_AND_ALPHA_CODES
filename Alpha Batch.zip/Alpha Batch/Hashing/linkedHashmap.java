import java.util.*;
//order of insertion is preserved in case of linkedHashmap but order of insertion is not preserved in case of hashmap.

public class linkedHashmap {
    public static void main(String[] args) {
        HashMap<String , Integer> hm = new HashMap<>();

        hm.put("India", 100);
        hm.put("Pakistan", 30);
        hm.put("US", 75);
        hm.put("Srilanka", 75);


        LinkedHashMap<String , Integer> lhm = new LinkedHashMap<>();

        lhm.put("India", 100);
        lhm.put("Pakistan", 30);
        lhm.put("US", 75);
        lhm.put("Srilanka", 75);

        System.out.println(hm);
        System.out.println(lhm);
    }
}
