import java.util.*;

public class tmap {
    public static void main(String[] args) {
        HashMap<String , Integer> hm = new HashMap<>();

        hm.put("India", 100);
        hm.put("Pakistan", 30);
        hm.put("US", 75);
        hm.put("Srilanka", 75);

        TreeMap<String , Integer> tm = new TreeMap<>();

        tm.put("India", 100);
        tm.put("Pakistan", 30);
        tm.put("US", 7);
        tm.put("Srilanka", 75);

        System.out.println(hm);
        System.err.println(tm);

        
    }
}
