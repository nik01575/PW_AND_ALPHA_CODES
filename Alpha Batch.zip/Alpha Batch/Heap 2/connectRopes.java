import java.util.Arrays;

public class connectRopes {
    public static void main(String[] args) {
        int arr[] = {4 , 3 , 2 , 6};
        int sum ;
        int sum2;

        Arrays.sort(arr);

        for(int i=0; i<arr.length-1; i++){
            sum = arr[i]+arr[i+1];
            sum2 = sum+arr[i];
            System.out.println(sum2);
        }
        
    }
}
