public class slidingWindow {
    public static void main(String[] args) {
        
    }
}
