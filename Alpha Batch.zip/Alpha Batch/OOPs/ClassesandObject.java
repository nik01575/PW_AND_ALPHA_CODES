class Pen
{
    String color;
    int tip;
    void setColor( String newcolor)
    {
        color= newcolor;
    }
    void tip( int newTip)
    {
        tip = newTip;
    }
}

public class ClassesandObject
{
    public static void main(String[] args) {

        Pen p1 = new Pen();

        p1.setColor("Red");
        System.out.println(p1.color);

        p1.tip(8);
        System.out.println(p1.tip);

        // p1.setColor("Yellow");

        p1.color = "Yellow";
        System.out.println(p1.color);
        
    }
}