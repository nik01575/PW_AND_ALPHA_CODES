class Pen{
    String color;
    int tip;

    Pen()                    // Non Parameterised Constructor
    {
        System.out.println("Default Constructor");
    }
    Pen(String color)                 // Parameterised Constructor
    {
        this.color = color;
    }
    Pen(int tip)                 // Pmultiple Constructor can be created
    {
        this.tip = tip;
    }
        
        
}

public class Construction {
    public static void main(String[] args) {
        
        // Pen p = new Pen("red");
        // System.out.println(p);


        Pen p = new Pen("Natural green");
        Pen p1 = new Pen(7);
        Pen p2 = new Pen();

        System.out.println(p.color);
        System.out.println(p1.tip);
        System.out.println(p2.tip);


        
    }
}
