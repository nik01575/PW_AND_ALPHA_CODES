class Pen{
   private String color;
    private int tip;

    void setColor(String color)
    {
        this.color= color;
    }
    void setTip(int newtip)
    {
        tip = newtip;
    }

    String getColor()
    {
        return this.color;
    }
    
    int getTip()
    {
        return this.tip;
    }
}

public class GetSet {
    public static void main(String[] args) {
        
        Pen p1 = new Pen();

        p1.setColor("Red");
        System.out.println(p1.getColor());

        p1.setTip(9);
        System.out.println(p1.getTip());

    }
}
