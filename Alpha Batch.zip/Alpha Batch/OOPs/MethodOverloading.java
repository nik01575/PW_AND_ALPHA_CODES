class Calculator   //same class but different parameters , but compiler detects this already during compile time  , kon sa object kis parameters ko pass kar rha hai
{
    int sum(int a, int b)
    {
        return a+b;
    }
    float sum(float a, float b)
    {
        return a+b;
    }
    int sum(int a, int b , int c)
    {
        return a+b+c;
    }
}

public class MethodOverloading {
    public static void main(String[] args) {
        
        Calculator c =new Calculator();
         int n = c.sum(2, 5);
         System.out.println(n);

         System.out.println( c.sum(3, 5, 2) );

         System.out.println( c.sum((float)3.5, (float)1.5) );
    }
}
