class Animal
{
    void eat()
    {
        System.out.println("Animal is Eathing");
    }
}

class Bird extends Animal
{
    void eat()
    {
        System.out.println("Birds are eating");
    }
}

public class MethodOverriding {
    public static void main(String[] args) {
        
        Bird b = new Bird();      //birds se eat() function ko call karenge to birds wala eat method he call hoga  ,, override nhi karega animal k eat( ) function ko
        b.eat();   
        
        Animal a = new Animal();   //animal se eat() function ko call karenge to animal wala eat method he call hoga
        a.eat();
    }
}
