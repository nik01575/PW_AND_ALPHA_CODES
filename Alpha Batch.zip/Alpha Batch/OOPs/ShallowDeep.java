class Students
{
    String name;
    int roll;
    String password;
    int marks[];

    // Students(Students s1)          // Shallow copy constructor
    // {
    //     marks = new int[3];
    //     this.name = s1.name;
    //     this.roll = s1.roll;
    //     this.marks = s1.marks;
    // }

    Students(Students s1)          // Deep copy constructor
    {
        marks = new int[3];
        this.name = s1.name;
        this.roll = s1.roll;
         
        for( int i=0 ; i<marks.length; i++)
        {
            this.marks[i]=s1.marks[i];
        }
    }

    Students()
    {
        marks = new int[3];
        System.out.println("Constructor Is Called");
    }
    Students(String name)
    {
        marks = new int[3];
        this.name = name;
    }
    Students(int roll)
    {
        marks = new int[3];
        this.roll = roll;
    }
}

public class ShallowDeep {
    public static void main(String[] args) {
        
        Students s1 = new Students();
        s1.name= "Nikhil";
        s1.roll = 20;
        s1.password = "abcde";
        s1.marks[0] = 80;
        s1.marks[1] = 90;
        s1.marks[2] = 100;

        Students s2 = new Students(s1);
        s2.password="xyz";
        s1.marks[2] = 200;

        for(int i = 0 ; i<3; i++)
        {
            System.out.println(s2.marks[i]);
        }



    }
}
