abstract class Animal1
{
    String color;
    Animal1()
    {
        System.out.println("Animal Constructor is Called");
    }
    void sleep()
    {
        System.out.println("Animal's Sleep");
    }

    abstract void walk();
}

class Horse extends Animal1
{
    Horse()
    {
        System.out.println("Horse Class is Called");
    }
    // void changecolor()
    // {
    //     color = "black";
    // }

    void walk()
    {
        System.out.println("Horse Walk's ");
    }
}

class Dog extends Horse
{
    Dog()
    {
        System.out.println("Dog Constructor Is called");
    }
    // void changecolor()
    // {
    //     color = "White";
    // }

    void walk()
    {
        System.out.println("Dog Walk's ");
    }
}

public class abstract1 {
    public static void main(String[] args) {


        
        Dog d =new Dog();
        

        // h.walk();
        // h.sleep();
        // h.changecolor();

        // Dog d = new Dog();
        // d.walk();
        // d.sleep();

        // Animal1 ani = new Animal1() {          // we can not create objects of abstract classes are not created
        // };


    }
}
