interface chess 
{
    void move();
}
class Rook 
{
    public void move()
    {
        System.out.println(" up, down ");
    }
}

class ghoda implements chess
{
    public void move()
    {
        System.out.println("  bottom, down, straight");
    }
}

public class interface1 {
    public static void main(String[] args) {
     
        ghoda g = new ghoda();
        g.move();
    }
}
