interface Herbivorus
{
    void eat();
  
}
interface Carnivorus
{
    void eat();
}

class Bear implements Carnivorus , Herbivorus
{
    public void eat()
    {
        System.out.println(" Eats BOth");
    }
}

public class interface2 {
    public static void main(String[] args) {
     
        Bear b = new Bear();
        b.eat();
    }
}
