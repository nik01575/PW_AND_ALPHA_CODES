class Animals
{
    String color;

    void eat()
    {
        System.out.println("Fishes Eat");
    }
    void breathe()
    {
        System.out.println("Fishes breathes");
    }
}

class Fishes extends Animals
{
    int life;

    void swim()
    {
        System.out.println("Fishes swim");
    }
}
class Mammals extends Fishes
{
    int name;

    void mammal()
    {
        System.out.println("Mammals live on Earth Planet");
    }
}

public class multiInheritance {
    public static void main(String[] args) {
        
        Mammals f = new Mammals();

        f.swim();
        f.eat();
        f.breathe();
        f.mammal();
    }
}

