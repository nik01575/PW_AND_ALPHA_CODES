class student
{
    static String schoolName;

    static int result(int p , int c , int m)
    {
        return(p+c+m);
    }
     
    

}

public class static1 {
    public static void main(String[] args) {
        
        // student s = new student();
        // s.schoolName = "ABC";
        // System.out.println(s.schoolName);

        // student s1 = new student();
        // s1.schoolName = "BCD";
        // System.out.println(s1.schoolName);
        

        // student s2 = new student();
        // System.out.println(s2.schoolName);

        student s = new student();
        System.out.println(s.result(50, 100, 150));

        student s1 = new student();
        System.out.println(s1.result(0, 0, 0));
    
        student s2 = new student();
        System.out.println(s2.result(0, 0, 0));
        
        
    }
}
