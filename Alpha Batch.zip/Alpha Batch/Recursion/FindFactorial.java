public class FindFactorial {
    public static int print(int n)
    {
        if(n==0)
        {
            return 1;
        }

        int fact = print(n-1);   
        int m = n*fact;
          
        return m;
    }
    public static void main(String[] args) {
        int n =5;
        System.out.println(print(n));
        
        
    }
}
