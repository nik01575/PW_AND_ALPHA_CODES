public class FirstNsum {
    public static int sum(int n)
    {
        if(n==1)
        {
            return 1;
        }
        int s =sum(n-1);
        int m = n+s;
        return m;
    }
    public static void main(String[] args) {
        int n =20;
        System.out.println(sum(n));
    }
}
