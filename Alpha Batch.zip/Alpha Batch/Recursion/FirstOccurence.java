public class FirstOccurence {
    public static int check(int arr[] , int target , int i)
    {
        if(i==arr.length)
        {
            return 0;
        }
        if(arr[i]==target)
        {
            return i;
        }
        return check(arr, target, i+1);
    }

    public static void main(String[] args) {
        int arr[] = { 2 , 4 , 6 , 8 , 10 , 14 , 11};
        System.out.println(check(arr , 11 , 0));
    }
}
 