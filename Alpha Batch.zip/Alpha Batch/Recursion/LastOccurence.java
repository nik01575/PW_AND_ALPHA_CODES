public class LastOccurence {
    public static void check(int arr[] , int target )
    {
        for(int i=arr.length-1; i>=0 ; i--)
        {
            if(arr[i]==target)
            {
                System.out.println("Element found at " + i);
                break;
            }
            else{
                System.out.println("Element Not found");
            }
        }
      
    }
    public static void main(String[] args) {
        int arr[] = { 2 , 4 , 6 , 8 , 10 , 10 , 11 , 1 , 4 , 10 , 1 , 4};
        check(arr , 4);
    }
}
