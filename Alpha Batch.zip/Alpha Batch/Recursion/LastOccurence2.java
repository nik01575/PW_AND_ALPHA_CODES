public class LastOccurence2 {
    public static int check(int arr[] , int target , int i)
    {
        if(i==arr.length)
        {
            return -1;
        }
        int isfound = check(arr , target , i+1);
        if(isfound!=-1 && arr[i]==target)
        {
            return i;
        }
        return isfound;
        
    }

    public static void main(String[] args) {
        int arr[] = { 2 , 4 , 6 , 8 , 10 , 14 , 10 ,11};
        System.out.println(check(arr , 10 , 0));
    }
}
 