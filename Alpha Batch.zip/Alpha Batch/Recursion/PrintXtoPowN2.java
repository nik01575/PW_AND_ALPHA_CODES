public class PrintXtoPowN2
{
    public static int check(int x , int y)
    {
        if(y==0)
        {
            return 1;
        }
        int pow = check(x , y/2);
        int powsq = pow * pow;
        
        if(y%2 != 0)
        {
            powsq = x * powsq;
        }
        return powsq;
    }
    public static void main(String[] args) {
        System.out.println(check(2 , 5));
    }
}