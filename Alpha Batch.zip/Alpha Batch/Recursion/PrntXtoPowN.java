public class PrntXtoPowN {

    public static int check(int x , int y)
    {
        if(y==0)
        {
            return 1;
        }
        // int xNmin1 = check(x, y-1);
        // int xn = x * xNmin1;
        // return xn;
        return x * check(x, y-1);
    }
    public static void main(String[] args) {
        System.out.println(check(2 , 10));
        
    }
}
