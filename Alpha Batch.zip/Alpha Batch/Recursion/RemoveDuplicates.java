public class RemoveDuplicates {

    public static void duplicates(String str , int indx , StringBuilder newStr , boolean map[])
    {
        if(indx == str.length())
        {
            System.out.println(newStr);
            return;
        }

        char currentChar = str.charAt(indx);
        if(map[currentChar-'a'] == true)
        {
            duplicates(str, indx+1, newStr, map);
        }
        else
        {
            map[currentChar-'a'] = true;
            duplicates(str, indx+1, newStr.append(currentChar), map);
        }
    }
    public static void main(String[] args) {
        
        String str = "appnnacollege";
        duplicates(str, 0, new StringBuilder(""), new boolean[26]);
    }
}
