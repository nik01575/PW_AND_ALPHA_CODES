public class TilingProblem {
    public static int sol(int n)         //size of the floor = 2*n
    {
        //base case 
        if(n==0 || n==1)
        {
            return 1;
        }

        // //verticle tiles
        // int vertical= sol(n-1);

        // //horizontal tiles
        // int horizontal = sol(n-2);

        // int total = vertical + horizontal;
        // return total;

         return sol(n-1) +  sol(n-2);
    }
    public static void main(String[] args) {
        int n = 4;
        System.out.println(sol(n));
    }
}
