public class Concatenate {
    public static void main(String[] args) {
        
        String frstName = "Nikhil";
        String lastName = "Raj";
        String fullName = frstName + " " + lastName ;
        System.out.println(fullName);

        System.out.println(frstName.charAt(5));
    }
}
