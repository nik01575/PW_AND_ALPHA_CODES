public class SubString {

    public static void main(String[] args) {
        String str = "HelloWorld";
        System.out.println(str.substring(0, 5));
    }
}
