import java.util.*;

public class basic 
{
    public static void main(String[] args) {
        // char arr[] = { 'a' , 'b' , 'c' , 'd' , 'd'};
        // String str = "abcde";
        // String str2 = new String("defgh");

        // //Strings are IMMUTABLE

        System.out.println("Enter Your Name");
        Scanner sc = new Scanner(System.in);
        String name= sc.nextLine();
        
        System.out.println("Your name is " + name);

        int len = name.length();
        System.out.println("Length Of the String Is :" + len);

        sc.close();
    }
}