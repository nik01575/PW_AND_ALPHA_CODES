public class FloydTriangle {
    public static void main(String[] args) {
        
        int a = 4;
         int b =4;
         int count = 1;

         for(int i = 1; i<=a ; i++)
        {
            for(int j=1; j<=b; j++)
            {
                if(i==a || j==1 || i>=j)
                {
                    
                 System.out.print(count+" ");
                 count++;
                }
                else
                {
                System.out.print("  ");
                }
            }
            System.out.println();
        }

    }
}
