public class HollowRectangle
{
    public static void main(String[] args) {
        
        int a = 5;
        int b = 5;

        for(int i = 0 ; i<=a ; i++)
        {
            for(int j =0 ; j<=b ; j++)
            {
                if( i == a || j ==b || i ==0 || j ==0)
                {
                    System.out.print("* ");
                }
                else
                {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
       
    }
}