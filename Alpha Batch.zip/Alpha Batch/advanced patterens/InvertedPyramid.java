public class InvertedPyramid {
    public static void main(String[] args) {
        int a = 4;
        int b = 4;

        for(int i = 1; i<=a ; i++)
        {
            for(int j=1; j<=b; j++)
            {
                if(i==a || j==b || i+ j>= 5)
                {
                 System.out.print("* ");
                }
                else
                {
                System.out.print("  ");
                }
            }
            System.out.println();
        }
    }
}
