import java.lang.annotation.*;



@Target({ElementType.TYPE , ElementType.FIELD, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@interface cricketPlayer
{
    String Country() default "india" ;
    int age() default 30 ;
}


@cricketPlayer //(age = 99) //(Country = "india")             //---------------->
class Virat
{
    @cricketPlayer          //---------------->
    private int innings;
    private int runs;

    @cricketPlayer          //---------------->
    public int getInnings()
    {
        return innings;
    }
    public void setInnings(int innings)
    {
        this.innings = innings;
    }
    public int getRuns()
    {
        return runs;
    }
    public void setRuns(int runs)
    {
        this.runs = runs;
    }

}


public class CUSTOMANNOTATION {
    public static void main(String[] args) {

        Virat v = new Virat();
        v.setInnings(20);
        v.setRuns(220);

        System.out.println(v.getInnings());
        System.out.println(v.getRuns());

        Class c= v.getClass();       //used to get annotations values
        Annotation a =  c.getAnnotation(cricketPlayer.class);
        cricketPlayer cp =  (cricketPlayer)a;

        String country =cp.Country();
        System.out.println(country);
        int age = cp.age();
        System.out.println(age);
    }
}
