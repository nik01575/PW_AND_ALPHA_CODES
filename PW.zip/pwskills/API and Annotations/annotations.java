@FunctionalInterface
interface Demo
{
    void show();
    // void show1();
}

// Parent Class

class Plane {
    public void planeFlies() 
    {
        System.out.println("Plane Flies");
    }
}


// Extends the Parent Class "Plane"
class cargoPlane extends Plane {

    @Override     // annotatins
    public void planeFlies() 
    {
        System.out.println("Cargo Plane is Flying");
    }
}

public class annotations {
    public static void main(String[] args) {

        // Object Of Child Class

        Plane p = new cargoPlane();
        p.planeFlies();
    }

}
