// import java.util.Date;

public class dateandtimeapi
{
    public static void main(String[] args) {
        
        java.util.Date dt = new java.util.Date();
        System.out.println(dt);

        long time = dt.getTime();

        java.sql.Date dt1 = new java.sql.Date(time);
        System.out.println(dt1);
    }
}