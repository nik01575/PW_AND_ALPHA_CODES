// to create named constant
enum Week
{
    MON , TUE , WED , THU , FRI , SAT
}

public class enum1 {
    public static void main(String[] args) {

        // enum Result
        // {
        //     PASS, FAIL, NORESULT
        // }


        //  Result r = Result.FAIL;
        //  System.out.println(r);



        
        // System.out.println(Week.MON);
        Week w = Week.MON;
        System.out.println(w);

        int i = Week.SAT.ordinal();
        System.out.println("Your Index Is : " + i);

        Week wr[] = Week.values();
        for(Week w1:wr)
        {
            System.out.println( w1 + " : " + w1.ordinal() );
        }

        
    }
}
