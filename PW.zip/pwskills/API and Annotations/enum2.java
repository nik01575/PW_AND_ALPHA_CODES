
enum Result{
    PASS, FAIL, NORESULT ;

    int marks;         //variablle

    Result()
    {
       System.out.println("Constructor in Enum");     //Constructor
    }

    void SetMarks(int marks)                           //Methods
    {
        this.marks = marks;
    }

    int getmarks()                                    //Methods
    {
        return marks;
    }

}

public class enum2 {
    public static void main(String[] args) {
        
        Result.PASS.SetMarks(99);
        int res = Result.PASS.getmarks();
        System.out.println(res);

        int res1 = Result.FAIL.getmarks();
        System.out.println(res1);

        Result.NORESULT.SetMarks(80);
        int res2 = Result.NORESULT.getmarks();
        System.out.println(res2);
       
    }
    
}
