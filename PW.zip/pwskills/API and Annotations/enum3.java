enum Result
{
    PASS, FAIL, NORESULT ;
}

public class enum3 {
    public static void main(String[] args)
    {
        Result res = Result.NORESULT;

        switch (res) {
            case PASS: System.out.println("Passed");
                break;
            case FAIL: System.out.println("Failed");
                break;
            case NORESULT: System.out.println("No Result Found");
                break;
        }
    }
    
}
