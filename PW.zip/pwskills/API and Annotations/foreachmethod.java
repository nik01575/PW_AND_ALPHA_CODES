import java.util.*;
public class foreachmethod {
    public static void main(String[] args) {
        
        List<Integer> li = new ArrayList<Integer>();
        li.add(4);
        li.add(2);
        li.add(6);
        li.add(9);
        li.add(14);
        System.out.println(li);

        // List<Integer> list = Arrays.asList(4, 2, 6, 9, 14);
        // System.out.println(list);

        for (Integer i : li)   //External For each
        {
            System.out.println(i);
        }


        li.forEach(i-> System.out.println(i) ); //inbuilt method
    }
}
