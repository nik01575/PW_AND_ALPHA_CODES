import java.util.*;
import java.util.stream.*;

public class stramapi {
    public static void main(String[] args) {
        
        List<Integer> list = Arrays.asList(4, 2, 6, 9, 14);
        System.out.println(list);

        Stream<Integer> stream = list.stream();
        stream.forEach(n-> System.out.println(n));
    }
}
