import java.util.*;
import java.util.stream.*;

public class stream{
    public static void main(String[] args) {

        List<Integer> list = Arrays.asList(2, 4, 6, 8 , 10);
        
        List<Integer> list1 = new ArrayList<Integer>();
        list1.add(2);
        list1.add(4);
        list1.add(6);
        list1.add(8);
        list1.add(10);

        System.out.println(list);
        System.out.println(list1);

        Stream<Integer> str =list.stream();
        Stream<Integer> str1 =list1.stream();

        str.forEach(n-> System.out.println(n) );
        str1.forEach(n-> System.out.println(n) );


    }
}