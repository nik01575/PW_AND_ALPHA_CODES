import java.util.stream.*;
import java.util.*;

public class stream2 {
    public static void main(String[] args) {
        
        List<Integer> list = Arrays.asList(2, 4, 8 ,5 , 6 , 0);
        System.out.println(list);


        
        Stream<Integer> str =list.stream();
        str.forEach(n-> System.out.println(n) );


        Stream<Integer> str1 =list.stream();
        System.out.println("Total No = " + str1.count());


        System.out.println("The Sorted Order :");
        Stream<Integer> str2 =list.stream();
        Stream<Integer> sorted =str2.sorted();
        sorted.forEach(n-> System.out.println(n) );


        System.out.println("Array modified");
        Stream<Integer> str3 =list.stream();
        Stream<Integer> sorted2 = str3.sorted();
        Stream<Integer> map = sorted2.map(n-> n*4);
        map.forEach(n-> System.out.println(n));




        System.out.println("Filtered Data");
        Stream<Integer> str4 = list.stream();
        Stream<Integer> filter = str4.filter(n-> n%2==0);
        Stream<Integer> sorted3 = filter.sorted();
        Stream<Integer> map2 = sorted3.map(n-> n*2);
        map2.forEach(n-> System.out.println(n));


        System.out.println("Using Multiple Streams in Single Line");
        Stream<Integer> str5 = list.stream();
        Stream<Integer> filter2 = str5.filter(n-> n%2==0)
        .filter(n-> n%2==0)
        .sorted()
        .map(n-> n*3);
        filter2.forEach(n-> System.out.println(n));





        



        
        
    }
}
