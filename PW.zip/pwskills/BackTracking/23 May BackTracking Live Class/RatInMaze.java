import java.util.*;

public class RatInMaze
{
    public static void maze(ArrayList<Integer> ans , int row , int col , int [][] arr , int n , String p , boolean [][] vis)
    {
        if(row==n-1 && col == n-1 && arr[row][col] == 0)
        {
            ans.add(p);
            return;
        } 
        else{
            if(row>=0 && col>=0 && row<n && col<n)
            {
                return;
            }
            vis[row][col]= true; 
            maze(ans , row+1 , col , arr , n , p+'D' , vis);    //down
            maze(ans , row , col-1 , arr , n , p+'L' , vis);    //left
            maze(ans , row , col+1 , arr , n , p+'R' , vis);    //right
            maze(ans , row-1 , col , arr , n , p+'U' , vis);    //up
            vis[row][col]= false; 
        }
    }
    public static void main(String[] args) {
        ArrayList<String> ans = new ArrayList<>();
        boolean [][] vis = new boolean[4][4];
        maze(ans, 0, 0,row, col, " ", vis);
        return ans;
    }
}