import java.util.ArrayList;
import java.util.Arrays;

public class StringSequence {

    public static void PrintSequence(int arr[] , int index , ArrayList<Integer> temparr)
    {

        //base case
        if(index == arr.length)
        {
            if(temparr.size()>0)
            {
                System.out.println(temparr);
            }
            return;
        }
        //recursion
        PrintSequence(arr, index+1, temparr);
        temparr.add(arr[index]);
        PrintSequence(arr, index+1, temparr);
        temparr.remove(temparr.size()-1);
    }
    public static void main(String[] args) {
        
        int arr[] = {1 , 2 , 3};
        System.out.println("For the array " + Arrays.toString(arr));
        PrintSequence(arr, 0, new ArrayList<>());
    }
}
