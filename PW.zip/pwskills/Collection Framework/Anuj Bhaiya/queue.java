import java.util.*;
import java.util.Queue;
public class queue
{
    public static void main(String[] args) {
        
        List que = new LinkedList();
        Queue quea = new LinkedList();
        
        
    }
}