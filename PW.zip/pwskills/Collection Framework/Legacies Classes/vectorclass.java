import java.util.*;
import java.util.Vector;

public class vectorclass {
    public static void main(String[] args) {
        
        Vector vc = new Vector();
        vc.add(50);
        vc.add(250);
        vc.add(350);
        vc.add(450);
        vc.add(560);
        vc.add(260);
        System.out.println(vc);

        Enumeration en = vc.elements();
        while(en.hasMoreElements())
        {
            System.out.println(en.nextElement()); 
        }

        Iterator ic = vc.iterator();
        while(ic.hasNext())
        {
          System.out.println(ic.next());
        }
    }
}
