import java.util.*;

public class array
{
    public static void main(String[] args) {
        
        ArrayList al1 = new ArrayList();
        
        al1.add(100);
        al1.add(200);
        al1.add(900);
        al1.add("Nikhil");
        al1.add(6.8);

        System.out.println(al1);

        // ArrayList al = new ArrayList();
        
        // al.add(400);
        // al.add(300);
        // al.add(200);
        // al.add("Raj");
        // al.add(9.8);

        // System.out.println(al);

        // System.out.println("After adding");

        // al.addAll(al1);
        // System.out.println(al);

        al1.add(3, "FIRST NAME");
        al1.add(2, 1);
        System.out.println(" New Arraylist IS: " + al1);

        System.out.println(al1.contains("Nikhil"));
        System.out.println(al1.indexOf("Nikhil"));
        System.out.println(al1.size());
        al1.ensureCapacity(20);
        System.out.println(al1.size());
    }
}