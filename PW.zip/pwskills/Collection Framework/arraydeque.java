import java.util.*;

public class arraydeque {
    public static void main(String[] args) {
        ArrayDeque ad = new ArrayDeque();
        // ad.add(100);
        // ad.add(200);
        // ad.add(300);
        // ad.add(400);
        // System.out.println(ad);

        // ad.addFirst(0);
        // ad.addLast(9999);
        // System.out.println(ad);

        // ad.addLast("Nikhil");
        // System.out.println(ad);

        // System.out.println("--------------------------------------");

        ad.offer(500);
        ad.offer(600);
        ad.offer(700);
        System.out.println(ad);

        ad.offerFirst(0);
        ad.offerLast(9999);
        System.out.println(ad);

        ad.offer("Nikhil");
        System.out.println(ad);
    }
}
