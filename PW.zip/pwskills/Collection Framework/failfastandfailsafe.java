import java.util.*;
import java.util.concurrent.*;

public class failfastandfailsafe {
    public static void main(String[] args) {
        
        ArrayList al = new ArrayList();
        al.add(90);
        al.add(190);
        al.add(290);
        al.add(390);
        al.add(490);
        al.add(990);
        al.add(790);
        System.out.println(al);

        // ------------------------failfast---------------------
        // Iterator  itr = al.iterator();
        // while(itr.hasNext())
        // {
        //     System.out.println(itr.next());
        //     al.add(600);
        // }

        CopyOnWriteArrayList al1 = new CopyOnWriteArrayList();
        al1.add(90);
        al1.add(190);
        al1.add(290);
        al1.add(390);
        al1.add(490);
        al1.add(990);
        al1.add(790);
        System.out.println(al1);

        // ------------------failSafe-----------------

        Iterator  itr1 = al1.iterator();
        while(itr1.hasNext())
        {
            System.out.println(itr1.next());
            al1.add(600);
        }

    }
}
