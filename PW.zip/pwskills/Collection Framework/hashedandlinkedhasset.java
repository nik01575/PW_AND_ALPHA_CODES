import java.util.HashSet;
import java.util.LinkedHashSet;

public class hashedandlinkedhasset {
    public static void main(String[] args) {
        HashSet hs = new HashSet();
        hs.add(50);
        hs.add(150);
        hs.add(520);
        hs.add(503);
        hs.add(653);
        hs.add(609);
        // hs.add(609);    HashSet and LinkedHashSet both does not allow duplicates values

        System.out.println(hs);

        LinkedHashSet hs1 = new LinkedHashSet();
        hs1.add(50);
        hs1.add(150);
        hs1.add(520);
        hs1.add(503);
        hs1.add(250);
        hs1.add(50);

        // hs1.add(50);    HashSet and LinkedHashSet both does not allow duplicates values

        System.out.println(hs1);

        
    }
}
