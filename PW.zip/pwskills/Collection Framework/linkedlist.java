import java.util.*;
public class linkedlist {
    public static void main(String[] args) {
        
        LinkedList ll = new LinkedList();

        ll.add(44);
        ll.add(54);
        ll.add(64);
        ll.add("IS ARE AM");

        System.out.println(ll);

        // ll.addFirst(0);
        // System.out.println(ll);
        // ll.addLast(100);
        // System.out.println(ll);

        // ll.add(1, 0);
        // System.out.println(ll);

        System.out.println(ll.peek());
        System.out.println(ll);
        System.out.println(ll.poll());
        System.out.println(ll);


    }
}
