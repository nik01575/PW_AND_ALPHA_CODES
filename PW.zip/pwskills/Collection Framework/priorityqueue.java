import java.util.PriorityQueue;

public class priorityqueue {
    public static void main(String[] args) {
        
        PriorityQueue pq = new PriorityQueue();
        pq.add(25);
        pq.add(55);
        pq.add(75);
        pq.add(100);
        pq.add(125);
        pq.add(225);
        pq.add(250);

        System.out.println(pq);

         pq.add(25);  /*PriorityQueue adds duplicates values */

        // pq.add("NICK");

        System.out.println(pq);

    }
}
