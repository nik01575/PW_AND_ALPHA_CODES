import java.util.TreeSet;

public class treeset {
    public static void main(String[] args) {
        
        TreeSet ts = new TreeSet();
        ts.add(50);
        ts.add(150);
        ts.add(250);
        ts.add(350);
        ts.add(450);
        ts.add(550);
        ts.add(650);
        ts.add(750);
        System.out.println(ts);

        System.out.println(ts.higher(150));
        System.out.println( ts.lower(150));

        System.out.println(ts.higher(100));
        System.out.println( ts.lower(100));

        // System.out.println(ts.ceiling(150));
        // System.out.println( ts.floor(150));

        System.out.println(ts.ceiling(100));
        System.out.println( ts.floor(100));

       
    }
}
