public class MissingNum {
    public static void main(String[] args) {
        
        int [] arr = {1 , 2 , 3 , 7 , 6 , 5 };
        int n = arr.length;
        int sum =0;
        int m = n+1;

        int totalsum = (m*(m+1))/2;

        for(int i =0; i<n; i++)
        {
            sum += arr[i];
        }

        int missingNum =0;
        missingNum = totalsum - sum;

        System.out.println(missingNum);
    }
}
