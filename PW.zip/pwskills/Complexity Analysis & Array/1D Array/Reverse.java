import java.util.Arrays;

public class Reverse {
    public static void main(String[] args) {
        
        int [] arr = { 32 , 4 , 8 , 10 , 1 , 14 };


        int last = arr.length;
        

        for(int i=0; i<arr.length/2 ;i++)
        {
            int temp = arr[last - i -1];
            arr[last - i -1 ] = arr[i];
            arr[i]=temp;
        }
        // while(first<last)
        // {
        //     int temp = arr[last];
        //     arr[last] = arr[first];
        //     arr[first]=temp;

        //     first++;
        //     last--;
        // }

        for(int i =0; i<arr.length; i++)
        {
            System.out.print(arr[i] + "  ");
        }


        
    }
}
