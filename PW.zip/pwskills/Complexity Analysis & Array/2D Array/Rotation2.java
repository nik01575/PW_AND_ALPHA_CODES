import java.util.Arrays;

public class Rotation2 {

    public static void newMatrix(int array[][]) {
        int n = array.length;
        int m = array[0].length;

        for (int i = 0; i < n; i++) {
            for (int j = i; j < m; j++) {
                int temp = array[i][j];
                array[i][j] = array[j][i];
                array[j][i] = temp;
            }
        }

        // swaping

        for (int i = 0; i < n; i++) {
            int left = 0;
            int right = m - 1;

            while (left < right) {
                int temp = array[i][left];
                array[i][left] = array[i][right];
                array[i][right] = temp;

                left ++;
                right --;
            }
        }

    }

    public static void main(String[] args) {
        int array[][] = { { 1, 2, 3, 4 },
                { 5, 6, 7, 8 },
                { 9, 10, 11, 12 },
                { 13, 14, 15, 16 } };

        newMatrix(array);

        for (var elment : array) {
            System.out.println(Arrays.toString(elment));
        }
    }
}
