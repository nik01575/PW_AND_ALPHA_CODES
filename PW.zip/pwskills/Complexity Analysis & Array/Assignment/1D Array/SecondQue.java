public class SecondQue {
    public static void main(String[] args) {
        
        // int arr[] = {34,21,54,65,43};
        int arr[] = {4,3,6,7,1};

        for(int element: arr)
        {
            if(element%2==0)
            {
                System.out.println(element);
            }
        }
    }
}
