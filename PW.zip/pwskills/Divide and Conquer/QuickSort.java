public class QuickSort {
    public static int partition(int arr[] , int l , int h )
    {
        int i = l;

        //pivot as the first element 
        int pivot = arr[l];

        for(int j=l+1; j<=h ; j++)
        {
            if(arr[j] <= pivot)
            {
                i= i+1;
                //swap
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = arr[temp];
            }
        }
        int temp = arr[l];
        arr[l] = arr[i];
        arr[i] = temp;

        return i;
    }

    public static void QuickSort(int arr[] , int l , int h)
    {
        if(l < h)
        {
            //1.Divide the array into SubProblem 
            int m = partition(arr , l , h);
            //2.Conquer those subproblems via Recursion
            QuickSort(arr, l, m-1);
            QuickSort(arr, m+1, h);
        }
    }
     //function to display the Array
     public static void printArr(int arr[], int n)
     {
         for(int i=0; i<n; i++)
         {
             System.out.print(arr[i] + " ");
         }
     }
    public static void main(String[] args) {
        int arr[] = {50, 20 , 70 ,90 , 10 , 13 , 17 , 21};
        int n= arr.length;
        System.out.println("Array before Sort is : ");
        printArr(arr , n);

        QuickSort(arr , 0 , n-1);

        System.out.println("Array after Sorting is: ");
        printArr(arr , n);

        
    }
}
