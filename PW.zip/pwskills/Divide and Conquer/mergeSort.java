class mergeSort
{
    public static void mergeProcedure(int arr[] , int first , int mid , int last)
    {
        int i , j , k;

        //size of the left and right subarray
        int n1 = mid-first+1;
        int n2 = last- mid;
        
        //Create Left and Right subarray
        int[] leftarray = new int[n1];
        int[] rightarray = new int[n2];

        //Copy the data into left and right Subarray
        for(i=0; i<n1; i++)
        {
            leftarray[i]= arr[first+1];
        }
        for(j=0; j<n2; j++)
        {
            rightarray[j]= arr[mid+1+j];
        }

        //Comparision between element of left subarrya and rightsubarray
        i=0;
        j=0;
        k=first;
        while(i<n1 && j<n2)
        {
            if(leftarray[i] < rightarray[j])
            {
                arr[k] = leftarray[i];
                i = i+1;
            }
            else{
                arr[k] = rightarray[j];
                j = j+1;
            }
            k=k+1;
        }

        //Copy the remaining element from leftSubarray
        while(i<n1)
        {
            arr[k] =leftarray[i];
            i=i+1;
            k=k+1;
        }
        //Copy the remaining element from rightSubarray
        while(j<n2)
        {
            arr[k] =rightarray[j];
            j=j+1;
            k=k+1;
        }
    }
    public static void sort(int arr[] , int first , int last)
    {
        while(first < last)
        {
            //Divide
            int mid = first + (last-first)/2;
            //Conquer
            
            //left Subarray
            sort(arr, first, mid-1);
            //right Subarray
            sort(arr, mid+1, last);
            //Merge
            mergeProcedure(arr , first , mid , last);
        }
    }

    //function to display the Array
    public static void printArr(int arr[], int n)
    {
        for(int i=0; i<n; i++)
        {
            System.out.print(arr[i] + " ");
        }
    }
    public static void main(String[] args) {
        int arr[] = {50 , 20 , 40 , 90 , 88 , 11 , 13};
        int n = arr.length;

        System.out.println("Array before Sorting is :");
        printArr(arr, n);

        sort(arr , 0 , n-1);

        System.out.println("Array After Sorting is : ");
        printArr(arr , n);
    }
}