import java.util.*;

public class DFS {
    private int V;

    private LinkedList<Integer> adj[];

    @SuppressWarnings("Unchecked")
    public DFS(int v) {
        V = v;
        adj = new LinkedList[v];

        for (int i = 0; i < V; ++i) {
            adj[i] = new LinkedList<>();
        }
    }

    public void addEdge(int v, int u) {
        adj[v].add(u);
    }

    public void dfsTraversal(int v, boolean[] visited) {
        visited[v] = true;
        System.out.println(v + " ");

        Iterator<Integer> itr = adj[v].listIterator();

        while (itr.hasNext()) {
            int n = itr.next();

            if (!visited[n]) {
                dfsTraversal(n, visited);
            }
        }

    }

    public static void main(String[] args) {

        int v = 4;

        boolean[] visited = new boolean[v];

        DFS dfs = new DFS(v);
        dfs.addEdge(0, 1);
        dfs.addEdge(0, 2);
        dfs.addEdge(1, 2);
        dfs.addEdge(2, 0);
        dfs.addEdge(3, 3);
        dfs.addEdge(2, 3);

        System.out.println("DFS from vertex 1");
        dfs.dfsTraversal(1, visited);
    }
}