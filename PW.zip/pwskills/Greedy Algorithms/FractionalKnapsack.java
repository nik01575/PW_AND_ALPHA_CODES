import java.util.*;

public class FractionalKnapsack
{
    public static double getmaxValue(ItemValue [] arr, int Capacity)
    {
        //Sorting items by weight/profit ratio
        Arrays.sort(arr , new Comparator<ItemValue>() {
            @Override
            public int compare(ItemValue item1 , ItemValue item2)
            {
                double cpr1 = Double.valueOf(item1.profit / item1.weight);
                double cpr2 = Double.valueOf(item2.profit / item2.weight);

                if(cpr1<cpr2)
                {
                    return 1;
                }else{
                    return -1;
                }
            }
            
        });

        double totalValue = 0;

        for(ItemValue i : arr)
        {
            int curWt = (int)i.weight;
            int curProfit = (int)i.profit;

            //Weight can be picked whole
            if(Capacity - curWt >= 0)
            {
                Capacity = Capacity-curWt;
                totalValue = totalValue+curProfit;
            }else{
                //Items can be picked whole
                double fraction = ((double)Capacity / (double)curWt);
                totalValue = totalValue + (curProfit*fraction);
                Capacity = (int )(Capacity - (curWt * fraction));
                break;
            }
        }
        return totalValue;

    }

    static class ItemValue
    {
        int profit , weight;
        public ItemValue(int profit , int wt)
        {
            this.profit = profit;
            this.weight = wt;
        }
    }
    public static void main(String[] args) {
        ItemValue[] arr = { new ItemValue(25 , 5),
                            new ItemValue(75 , 10),
                            new ItemValue(100 , 12),
                            new ItemValue(50 , 4),
                            new ItemValue(45 , 7),
                            new ItemValue(90 , 9),
                            new ItemValue(30 , 3)};

        int Capacity = 37;
        double maxValue = getmaxValue(arr , Capacity);

        //Fuction Call
        System.out.println("Maximum Profit = " + maxValue);
    }
}