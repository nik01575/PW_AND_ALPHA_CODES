import java.util.*;

public class JobScheduling {
     char id;
     int deadline , profit ;
     public JobScheduling()
     {

     }
     public JobScheduling(char id , int deadline , int profit)
     {
        this.id = id ;
        this.deadline = deadline; 
        this.profit = profit;
     }

    void printJobSequence(ArrayList<JobScheduling> arr , int maxDeadline)
    {
        int n = arr.size();
        //STEP 1 ---- Sort the array in the decreasing order of profit

        //lambda expression
        Collections.sort(arr, (a,b) -> b.profit-a.profit);
        //keep the track of the booked slots
        boolean result[] = new boolean[maxDeadline];
        //to store the job id's
        char job[] = new char[maxDeadline];

        //STEP 2 ---- to store the jobs according to the given deadline

        for(int i=0; i<n ; i++)
        {
            for(int j= Math.min(maxDeadline-1, arr.get(i).deadline-1); j>=0; j--)
            {
                if(result[j] == false)
                {
                    result[j]= true;
                    job[j] = arr.get(i).id;
                    break;
                }
            }
        }

        //print
        for(char id:job)
        {
            System.out.print( id + "  ");
        }
        System.out.println();

    }
    public static void main(String[] args) {
        
        ArrayList<JobScheduling> arr = new ArrayList<>();
        arr.add(new JobScheduling('1', 5, 55));
        arr.add(new JobScheduling('2', 2, 65));
        arr.add(new JobScheduling('3', 7, 75));
        arr.add(new JobScheduling('4', 3, 60));
        arr.add(new JobScheduling('5', 2, 70));
        arr.add(new JobScheduling('6', 1, 50));
        arr.add(new JobScheduling('7', 4, 85));
        arr.add(new JobScheduling('8', 5, 68));
        arr.add(new JobScheduling('9', 3, 45));

        System.out.println("Job Sequences to get maximum profit");

        JobScheduling job = new JobScheduling( );
        job.printJobSequence(arr, 7);
    }
}
