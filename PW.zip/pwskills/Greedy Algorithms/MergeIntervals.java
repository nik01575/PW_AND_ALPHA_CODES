import java.util.*;

public class MergeIntervals {

    public static int [] [] merged(int [] [] intervals)
    {
         //STEP 1 - Sort the intervals in the increasing order of start value
        Arrays.sort(intervals , (a,b) -> Integer.compare(a[0], b[0]));

        //STEP 2 - Iterate for all the intervals and check for the overlapping intervals
        LinkedList<int[]> merged = new LinkedList<>();

        for(int [] interval:intervals)
        {
            //No overlapping
            if(merged.isEmpty() || merged.getLast()[1] < interval[0])
            {
                merged.add(interval);
            }else{
                //Overlapping
                merged.getLast()[1] = Math.max(merged.getLast()[1] , interval[0]);
            }
        }
        return merged.toArray(new int [merged.size()] []);
    }
    public static void main(String[] args) {
        
        int [][] intervals = {{1 , 3},
                              {2 , 6},
                              {8 , 10},
                              {15 , 18}};
        merged(intervals);
    }
}
