import java.util.HashMap;
import java.util.Map;

public class hashmapFunction
{
    public static void main(String[] args) {
        
        HashMap<Integer,String> hm = new HashMap<>();
        hm.put(1, "A");
        hm.put(3, "B");
        hm.put(5, "C");
        hm.put(7, "D");
        hm.put(9, "E");
        System.out.println("Hashmap for the given data is : " + hm);

        //functionality of get function
        String value = hm.get(5);
        System.out.println("The value of Key is : " + value);

        //functionality of containsKey functoion
        System.out.println( hm.containsKey(3));

        //functionality of remove function
        hm.remove(1);
        System.out.println("Updated HashMap " +  hm);

        //Iteration using the for loop
        for(Map.Entry<Integer , String> e:hm.entrySet())
        {
            System.out.println("Hashmap Is : " + e.getKey() + " : " + e.getValue());
        }
    }
}