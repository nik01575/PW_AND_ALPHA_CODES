import java.util.HashMap;

public class nonRepeatChar
{
    public static void main(String[] args) {

        String str = "PRIYAPR";

        //Contruction of Hashtable
        HashMap<Character , Integer> map = new HashMap<>();
        for(int i=0; i<str.length(); i++)
        {
            if(map.containsKey(str.charAt(i)))
            {
                map.put(str.charAt(i), map.get(str.charAt(i))+i);
            }
            else{
                map.put(str.charAt(i), 1);
            }
        }

        //Scan the hashtable and get the index of the non repeating character

        int result = -1;
        for(int i=0; i<str.length(); i++)
        {
            if(map.get(str.charAt(i))==1)
            {
                System.out.println("The first non Repeating char is : " + i);
                result = 1;
                break;
            }
        }

        if(result== -1)
        {
            System.out.println("No non repeating character is found");
        }

        
    //     String string = "PRIYAPR";
    //     int index = -1;
    //     char fnc = ' ';
       
    //    if(string.length()==0){
    //      System.out.println("EMPTY STRING");
    //    }
       
    //     for (char i : string.toCharArray()) {
    //         if (string.indexOf(i) == string.lastIndexOf(i)) {
    //             fnc = i;
    //             break;
    //         }
    //         else {
    //             index += 1;
    //         }
    //     }
    //     if (index == string.length()-1) {
    //         System.out.println("All characters are repeating");
    //     }
    //     else {
    //         System.out.println("First non-repeating character is " + fnc);
    //     }





        // char str[] = {'P' , 'R' , 'I' , 'Y' , 'A' ,'P' , 'R' };
        // int n = str.length;

        // for(int i=0 ;i<n; i++)
        // {
        //     for(int j=i+1; j<n; j++)
        //     {
        //         if(str[i] == str[j] )
        //         {
        //             break;
        //         }
        //         else if(str[i] != str[j] )
        //         {
        //             System.out.println("First Non Repeating char is " + i);
        //             return;
        //         }
        //     }
        // }
    }
} 