import java.util.HashMap;

public class twosum
{
    // public static void twoSum(int arr[] , int target)
    // {
        
    //     for(int i=0; i<arr.length; i++)
    //     {
    //         for(int j=i+1; j<arr.length; j++ )
    //         {
    //             if(arr[i] + arr[j] == target)
    //             {
    //                 System.out.println( i + " : " + j);
    //             }
    //             else{
    //                 System.out.println("Not found");
    //             }
    //         }
    //     }
    // }
    public static void main(String[] args) {
        
        int arr[] = { 2 , 7 , 11 , 15 , 0};
        int target = 2;
        int n = arr.length;
        int result[] = new int[2];

        // twoSum(arr , target);

        //Create a hashmap where key is arr[i] and value is i
        HashMap<Integer , Integer> map = new HashMap<>();
        for(int i=0; i< n; i++)
        {
            map.put(arr[i], i);
        }

        //If current is equal to the result
        for(int i=0; i<n ; i++)
        {
            if(arr[i] == target && map.containsKey(0))
            {
                result[0] = i;
                result[1] = map.get(0);
                break;
            }

            else if(map.containsKey(target - arr[i])){
                if(map.get(target - arr[i]) > i)
                {
                    result[0] = i;
                    result[1] = map.get(target - arr[i]);
                    break;
                }
            }
        }
        System.out.println("Two sum values are " + result[0] +" and " + result[1]);
    }
}