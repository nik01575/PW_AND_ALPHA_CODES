
import java.util.*;

public class typeHashMap {
    public static void main(String[] args) {
        
        //Order of insertion is not preserved
        HashMap<Integer,String> hm = new HashMap<>();
        hm.put(4, "A");
        hm.put(2, "B");
        hm.put(5, "C");
        hm.put(1, "D");
        hm.put(9, "E");
        System.out.println(hm);

        //Order of Insertion is preserved
        LinkedHashMap<Integer,String> hm1 = new LinkedHashMap<>();
        hm1.put(4, "A");
        hm1.put(2, "B");
        hm1.put(5, "C");
        hm1.put(1, "D");
        hm1.put(9, "E");
        System.out.println(hm1);


        //Sorted Order
        TreeMap<Integer,String> hm2 = new TreeMap<>();
        hm2.put(4, "A");
        hm2.put(2, "B");
        hm2.put(5, "C");
        hm2.put(1, "D");
        hm2.put(9, "E");
        System.out.println(hm2);


        
    }
}
