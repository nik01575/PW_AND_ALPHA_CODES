import java.util.*;

public class QueueUsingStack {

    static Stack<Integer> stack1 = new Stack<>();
    static Stack<Integer> stack2 = new Stack<>();

    //Insertion of Data in a Queue
    static void enQueue(int data)
    {
        stack1.push(data);
    }
    //Deletion of data from a Queue
    static int deQueue()
    {
        int element;
        if(stack1.empty() && stack2.empty())
        {
            System.out.println("Queue is empty");
            System.exit(0);
        }
        //If both stack are not empty then first step is to push the data items from stack1 to stack2.
        if(stack2.empty())
        {
            while(!stack1.empty())
            {
                element = stack1.pop();
                stack2.push(element);
            }
        }
        //Pop the element from stack2
        element = stack2.pop();
        return element;
    }
    public static void main(String[] args) {
        
        QueueUsingStack q = new QueueUsingStack();
        q.enQueue(1);
        q.enQueue(2);
        q.enQueue(3);
        q.enQueue(4);
        System.out.println(q.deQueue());
        System.out.println(q.deQueue());
        
    }
}
