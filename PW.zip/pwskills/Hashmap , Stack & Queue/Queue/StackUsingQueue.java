import java.util.*;

public class StackUsingQueue {

    static Queue<Integer> q1 = new LinkedList<>();
    static Queue<Integer> q2 = new LinkedList<>();

    static void add(int data)
    {
        //Move the elements from Q1 to Q2
        while(!q1.isEmpty())
        {
            q2.add(q1.peek());
            q1.poll();  //poll ---> remove element from queue
        }
        //Push the new data to Q1
        q1.add(data);
        //Move back all the element form Q2 to Q1
        while(!q2.isEmpty())
        {
            q1.add(q2.peek());
            q2.poll(); 
        }
    }

    static int remove()
    {
        if(q1.isEmpty())
        {
            System.out.println("Queue is Empty");
            System.exit(0);
        }
        int ele = q1.peek();
        q1.poll();
        return ele;
    }
    public static void main(String[] args) {
        
        StackUsingQueue s = new StackUsingQueue();

        //adding element in the Stack
        s.add(1);
        s.add(2);
        s.add(3);
        s.add(4);

        System.out.println("Deleted Element in the Stack is : " + s.remove());
    }
}
