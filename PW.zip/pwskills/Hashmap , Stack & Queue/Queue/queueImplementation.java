import java.util.*;

public class queueImplementation
{
    public static void main(String[] args) {
        Queue<Integer> q = new LinkedList<>();

        for(int i=0; i<10; i++)
        {
            q.add(i);
        }
        System.out.println("Queue is : " + q);


        q.remove();
        System.out.println("Queue is : " + q);


        System.out.println("Top element is : " + q.peek());

        System.out.println("Current size of queue is :" + q.size());
    }
}