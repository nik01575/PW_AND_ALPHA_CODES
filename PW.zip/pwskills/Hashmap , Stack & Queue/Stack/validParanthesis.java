import java.util.Stack;

public class validParanthesis {

    public static boolean isValid(String str)
    {
        char[] chars = str.toCharArray();

        Stack<Character> stack = new Stack<>();
        
        for(char ch :chars)
        {
            if(ch =='(' || ch == '{' || ch =='[')
            {
                stack.push(ch);
                continue;
            }
            else{
                //Closing
                if(stack.isEmpty())
                {
                    return false;
                }
                if(  (stack.peek() == '(' && ch == ')')  
                    || (stack.peek() == '[' && ch == ']')  
                    || (stack.peek() == '{' && ch == '}'))
                {
                    stack.pop();
                }
                else{
                    return false;
                }
            }
        }
        if(stack.isEmpty())
        {
            return true;
        }else{
            return false;
        }
        
    }
    public static void main(String[] args) {
        String str = "({[]{[]})";

        System.out.println("Given String is Valid ? : " + isValid(str));
    }
}
