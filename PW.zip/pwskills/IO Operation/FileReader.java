import java.io.*;

public class FileReader
{
    public static void main(String[] args) throws Exception
    {
        
 
       File dir = new File("demopw");
        File f1 = new File(dir, "pwtext.txt");

        FileReader fd = new FileReader(f1);

        int i = fd.read();

        while(i!= -1)
        {
            System.out.print(i + "--------->");
             System.out.println((char)i);
             i = fd.read();
        }

    }
}