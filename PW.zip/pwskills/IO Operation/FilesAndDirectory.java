import java.io.*;

public class FilesAndDirectory {
    public static void main(String[] args) throws Exception
    {
        
        File f1 = new File("demofile.txt");
        System.out.println(f1.exists());

        f1.createNewFile();      //for creating new file
        System.out.println(f1.exists());


        File dir= new File("demopw");
        System.out.println(dir.exists());

        dir.mkdirs();          // for creating new directory
        System.out.println(dir.exists());
    }
}
