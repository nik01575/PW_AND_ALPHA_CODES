
import java.io.*;

public class FilesClass {
    public static void main(String[] args) throws Exception
    {
        
        // File f = new File("demopw");   // for checking demopw file exists or not. If it exists then f1 starts refering it .
        // System.out.println( "demopw file exists : " + f.exists());

        // File f1 = new File(f, "pwtext.txt");   // for checking pwtext directory exist or not . 
        //  // System.out.println(f1.isFile());
        // f1.createNewFile();

        // System.out.println( "f1 is refering to pwtext.txt : " + f1.isFile());

        int count = 0;

        File f = new File("next");

        String str[] = f.list();

        for(String name : str)
        {
            count++;
            System.out.println(name);
        }

        System.out.println("No of files are : " + count);
    }
}
