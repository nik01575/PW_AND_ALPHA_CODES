import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;

class Cricketer implements Serializable
{
    private String name;
    private int age;
    private int runs;

    public Cricketer( String name, int age, int runs)
    {
        this.name = name;
        this.age = age;
        this.runs = runs;
    }

    public void display()
    {
        System.out.println(name);
        System.out.println(age);
        System.out.println(runs);
    }
}

public class NewSerializable {
    public static void main(String[] args) throws Exception
    {

        // Cricketer c = new Cricketer("Virat", 30, 99);
        // c.display();

        // FileOutputStream fos = new FileOutputStream("pw.txt");
        // ObjectOutputStream oos = new ObjectOutputStream(fos);

        // oos.writeObject(c);
        // oos.flush();
        // oos.close();


        FileInputStream fis = new FileInputStream("demofile.txt");
        BufferedInputStream bis = new BufferedInputStream(fis);
        ObjectInputStream ois = new ObjectInputStream(bis);

        Cricketer cr = (Cricketer)ois.readObject();
        cr.display();
        
        ois.close();
    }

}
