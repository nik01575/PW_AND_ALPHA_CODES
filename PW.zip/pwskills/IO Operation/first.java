class Student 
{
    private String name;
    private int age;
    private String city;

    public Student(String name , int age , String city)
    {
        this.name = name;
        this.age = age;
        this.city = city;
    }
    public String toString()
    {
        return name +" "+ age +" " + city ;
    }
}
public class first {
    public static void main(String[] args) {

        Student s = new Student("NIkhil", 19, "Bihar");
        System.out.println(s);

        Student s1 = new Student("Raj", 19, "Pune");
        System.out.println(s1);

        Student s2 = new Student("Shashi", 20, "Maharashtra");
        System.out.println(s2);
    }
}
