import java.io.*;

public class moreReader {
    public static void main(String[] args) {
        
        File dir = new File("demopw");
        File file = new File(dir,"pwtext.txt");

        FileReader fd= new FileReader(file);
        int i = fd.read();

        System.out.println((char)i);

        while(i!=1)
        {
            System.out.println(i + "------->");
            System.out.println((char)i);
            i = fd.read();

        }
    }
}
