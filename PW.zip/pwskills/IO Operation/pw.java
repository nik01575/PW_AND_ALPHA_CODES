import java.io.*;
public class pw 
{
    public static void main(String[] args) throws Exception
    {
       

         File dir=new File("demo");
         File file=new File(dir, "pwtext.txt");

         FileReader fd=new FileReader(file);
         char ch[]=new char[(int)file.length()];
        
        //  int i=fd.read();

         fd.read(ch);
         int FileReader.ch();
         
        //  System.out.println((char)i);

        //  while(i!=-1)
        //  {
        //     System.out.print(i+ "----> ");
        //     System.out.println((char)i);
        //     i=fd.read();

        //  }


        
    }
    
}