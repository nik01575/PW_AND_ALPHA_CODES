fw.write("Hello");
        fw.write("\n");
        fw.write("My ");
        fw.write("\n");
        fw.write("Name");
        fw.write("\n");
        fw.write("Is");
        fw.write("\n");
        fw.write("NIkhil");