import java.io.*;;

public class writingfile {
    public static void main(String[] args) throws Exception
     {
        
        File dir = new File("demopw");

        File ndir = new File(dir , "pwtext.txt");

        FileWriter fw = new FileWriter(ndir , true);

        fw.write("What ");
        fw.write("\n");
        fw.write("Is  ");
        fw.write("\n");
        fw.write("Your");
        fw.write("\n");
        fw.write("Name");
        fw.write("\n");
       
        fw.write("Hello");
        fw.write("\n");
        fw.write("My ");
        fw.write("\n");
        fw.write("Name");
        fw.write("\n");
        fw.write("Is");
        fw.write("\n");
        fw.write("NIkhil");
        fw.close();
        // fw.flush();

        System.out.println("Runned Successfully");


        


    }
}
