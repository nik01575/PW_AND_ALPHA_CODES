class animal
{
    public void sleep()
    {
        System.out.println("Tiger is a animal");
    }
}
class Tiger extends animal
{
    
}

public class final1{
    public static void main(String[] args)
    {
        animal an= new animal();
        an.sleep();
    }
}