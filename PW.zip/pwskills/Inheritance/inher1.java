class Human
{
    int age;
 void sleep()
    {
        age=20;
        System.out.println(" Human Needs Good Sleep");
        System.out.println(age);
    }
}

class Student extends Human
{
    protected void sleep()
    {
        age=20;
        System.out.println("Human Needs Money");
        System.out.println(age);
    }
}

public class inher1{
    public static void main(String[] args)
    {
        Student st= new Student();
        st.sleep();
    }
}