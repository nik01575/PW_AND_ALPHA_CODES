interface Car
{
    void drive();
}

// class BMW 
// {
//     public void drive()
//     {
//     System.out.println("BMW supercar");
//     }
// }

public class anonymousInner {
    public static void main(String[] args)
    {
        Car obj = new Car()
        {
            public void drive()
            {
               System.out.println("BMW supercar");
            }
        };

        obj.drive();
        
    }
}
