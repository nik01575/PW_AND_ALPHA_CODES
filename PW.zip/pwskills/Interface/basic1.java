interface Computer
{
     void compileCode();
     
}
class Laptop implements Computer
{
    public void compileCode()
    {
        System.out.println("You got 5 errors");
    }
}
class Desktop implements Computer
{
    public void compileCode()
    {
        System.out.println("You got 5 errors, Desktop is faster");
    }
}
class Developer
{
    public void buildApp(Computer obj)
    {
        System.out.println("Building App");
        obj.compileCode();
    }
}
public class basic1
{
    public static void main(String[] args)
    {
        Computer obj = new Desktop();
        //  Desktop obj = new Desktop();      
        Developer dev = new Developer();
        dev.buildApp(obj);
        
    }
}