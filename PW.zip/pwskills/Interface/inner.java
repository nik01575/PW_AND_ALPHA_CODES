class A
{
    public void show()
    {
        System.out.println("in class A");
    }

    //class B 
    static class B
    {
        public void display()
        {
            System.out.println("in class B");
        }
    }
}

public class inner {
    public static void main(String[] args)
    {
        A obj = new A();
        //A.B obj1 = obj.new B();
        A.B obj1 = new A.B();

        obj.show();

        
        obj1.display();
    }
}
