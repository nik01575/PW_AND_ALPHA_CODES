interface Car
{
    void drive( int avg , int tps);
}



public class lamda {
    public static void main(String[] args)
    {
        Car obj = ( avg , tps)  ->    

               System.out.println("BMW supercar " + avg  +  +  tps);

        obj.drive(20 , 100);
        
    }
}
