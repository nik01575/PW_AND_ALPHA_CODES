class LinkedList
{
    Node head;
    class Node{
        int data;
        Node next;

        Node(int d)
        {
            data = d;
            next = null;
        }
    }

    //Implement of insertion of a node at the end
    public void insertAtEnd(int newData)
    {
        Node newNode = new Node(newData);
        //LinkedList is empty
        if(head == null)
        {
            head = new Node(newData);
            return;
        }
        //LinkedList is not empty
        newNode.next = null;
        Node temp = head;
        while(temp.next != null)
        {
            temp = temp.next;
        }
        temp.next = newNode;
        return;
    }

    //Implementation of insert a node at the begining
    public void insertAtBegining(int newData)
    {
        Node newNode = new Node(newData);
        newNode.next = head;
        head = newNode;
    }
    //Implementation of insert a Node at any Position
    public void insertAtAny(Node prev_node , int newData)
    {
        if(prev_node == null)
        {
            System.out.println("Previous Node cannot contain null values");
        }
        Node newNode = new Node(newData);
        newNode.next = prev_node.next;
        prev_node.next = newNode;
    }

    //Displaying the LinkedList
    public void display()
    {
        Node current = head;
        while(current != null)
        {
            System.out.print(current.data + " ");
            current = current.next;
        }
    }

    //Implementatoin of deletion of a node
    void deleteNode(int position)
    {
        //check if linkedlist is empty or not
        if(head == null)
        {
            return;
        }
        //creation of new Node
        Node temp = head;

        //If deletion is at the begining
        if(position == 0)
        {
            head = temp.next;
            return;
        }
        //If deletion is not at the begining
        for(int i=0; temp!=null && i<position-1; i++)
        {
            temp = temp.next;
        }
        if(temp!=null && temp.next == null)
        {
            return;
        }
        temp.next = temp.next.next;
    }

    //Reversal of LinkedList
    public void reverse()
    {
        Node curr = head;
        Node prev = null;
        Node nextPt;

        while(curr!=null)
        {
            nextPt = curr.next;
            curr.next = prev;
            prev = curr;
            prev = nextPt;

            prev = curr;
            curr = nextPt;
        }

        head = prev;
     }
    
     //Implementation of Recursive Reversal
     public void recursiveReverse(Node curr , Node prev)
     {
        if(curr.next == null)
        {
            head = curr;
            curr.next = prev;
            return;
        }
        Node nextPtr = curr.next;
        curr.next = prev;

        recursiveReverse(nextPtr, curr);
     }

     //Implementation of finding middle of a node
     public void middleNode()
     {
        Node slow = head;
        Node fast = head;

        while(fast!=null && fast.next!=null)
        {
            slow = slow.next;
            fast = fast.next.next;
        }

        System.out.println("Middle element of linkedlist is : " + slow.data);
     }

     //Implementation of detecting loop in LinkedList
     //FLoyd's Cycle detection algorithm
     public void isCycle()
     {
        Node slow = head;
        Node fast = head;
        int flag=0;

        while(slow!=null && fast!=null && fast.next!=null)
        {
            slow = slow.next;
            fast = fast.next.next;

            if(slow == head)
            {
                flag =1;
                break;
            }
        }
        
        if(flag == 0)
        {
            System.out.println("No loop is detected");
        }
        else{
            System.out.println("Loop is detected");
        }
     }

    public static void main(String[] args) {
        
        LinkedList list = new LinkedList();
        list.insertAtEnd(2);
        list.insertAtEnd(4);
        list.insertAtEnd(6);
        list.insertAtEnd(8);

        System.out.println("Before Insertion of 10");
        list.display();
        System.out.println();

        System.out.println("After Insertion of 10");
        list.insertAtEnd(10);
        list.display();
        System.out.println();


        System.out.println("Insertion at First");
        list.insertAtBegining(1);
        list.display();
        System.out.println();

        System.out.println("Insertion at Random Place");
        list.insertAtAny(list.head.next.next, 99);
        list.display();
        System.out.println();

        System.out.println("Delete at Position 3");
        list.deleteNode(3);
        list.display();
        System.out.println();

        list.middleNode();


        Node temp= list.head;
        while(temp.next != null)
        {
            temp = temp.next;
        }
        temp.next = list.head;
        list.isCycle();


        // System.out.println("Iterative reversing");
        // list.reverse();
        // list.display();
        // System.out.println();

        // System.out.println("Recursive reversing");
        // list.recursiveReverse(list.head , null);
        // list.display();
        // System.out.println();

        // System.out.println("Insertion at Random Place");
        // list.insertAtAny(list.head, 199);
        // list.display();


    }
}