import java.util.*;

class Student
{
    int marks;
    int age;
    String name;

    public Student(int marks , int age , String name)
    {
        this.marks=marks;
        this.age=age;
        this.name=name;
    }

    public int getMarks() {
        return marks;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public String  toString(){
        return " " + marks + " "+ age + " " + name;
    }

  
}

class Alpha implements Comparator<Student>
{
    public int compare(Student a , Student b)
    {
        if(a.marks>b.marks)
        {
            return 1;
        }
        else
        {
            return -1;
        }
    }

}

public class ComparatorAndComparable {
    public static void main(String[] args) {
        
        Student s1 = new Student(55, 18, "Rahul");
        Student s2 = new Student(99 , 35, "Swe");
        Student s3 = new Student(45 , 60 , "Raghav");

        Alpha a = new Alpha();

        List<Student> list = new ArrayList<Student>();
        list.add(s1);
        list.add(s2);
        list.add(s3);

        Collections.sort(list, a);
        System.out.println(list);
    }
}
