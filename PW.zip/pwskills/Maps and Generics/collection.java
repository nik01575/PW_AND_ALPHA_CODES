
import java.util.*;

public class collection {
    public static void main(String[] args) {
        
        ArrayList al = new ArrayList();
        al.add(4000);
        al.add(5);
        al.add(5);
        al.add(5);
        al.add(6);
        al.add(44);
        al.add(35);
        al.add(345);
        al.add(366);

        System.out.println(al);
        Collections.sort(al);
        System.out.println(al);

        System.out.println("------------------------");
        
        int index = Collections.binarySearch(al, 366);
        System.out.println(" Your Index is : " + index);


        System.out.println("------------------------");
        
        Collections.rotate(al, 2);
        System.out.println("After Rotation " + al);

        System.out.println("------------------------");

        Collections.shuffle(al);
        System.out.println("After Shuffle "+  al);

        System.out.println("------------------------");

        System.out.println(  "Your Frequency Is : " + Collections.frequency(al, 5));

        System.out.println("------------------------");

        // ArrayList<String> al2 = new ArrayList<String>();
        // al2.add("PW");
        // al2.add("Skills");
        // al2.add("java");
        // al2.add("nik");
        // al2.add("virus");
        // al2.add("iphone");

        // System.out.println(al2);
        // Collections.sort(al2);
        // System.out.println(al2);

        // System.out.println("------------------------");
    }
}
