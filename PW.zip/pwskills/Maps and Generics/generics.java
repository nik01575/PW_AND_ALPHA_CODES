import java.util.*;
import java.util.Map.*;

public class generics {
    public static void main(String[] args) {
        

        //Type Safety
        // String ar[] = new String[10];
        // ar[0]= "Hyder";
        // ar[1]= "ALI";
        // ar[2]= "Nikhil";
        // // ar[3]= 4;
        
        // String name1 = ar[0];
        // String name2 = ar[1];
        // String name3 = ar[2];


        //No Type Safety
        //Type Safety achieved using generics

        ArrayList<String> arr = new ArrayList<String>();

        arr.add("nikhil");
        arr.add("Raj");
        arr.add("Satyam");
        arr.add("Shivam");
        // arr.add(8);

        // String n1 = (String)arr.get(0);
        // String n2 = (String)arr.get(1);
        // String n3 = (String)arr.get(2);
        // String n4 = (String)arr.get(3);

        String n1 = arr.get(0);
        String n2 = arr.get(1);
        String n3 = arr.get(2);

        

    }
}
