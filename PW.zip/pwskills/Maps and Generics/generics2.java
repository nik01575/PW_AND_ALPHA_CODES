import java.util.*;

class Student1
{
    private String name;
    private int id;
}
class Employe
{
    private String name;
    private int id;
}

public class generics2 {
    public static void main(String[] args) {
        
        Student1 st1 = new Student1();
        Student1 st2 = new Student1();

        Employe e = new Employe();

        ArrayList<Student1> al = new ArrayList<Student1>();

        al.add(st1);
        al.add(st2);
        // al.add(e);
    }
}
