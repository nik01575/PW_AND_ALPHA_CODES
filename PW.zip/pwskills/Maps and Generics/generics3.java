import java.util.*;

class Gen<T>
{
    T obj;

    public Gen( T obj)
    {
        this.obj=obj;
    }
    void display()
    {
        System.out.println("The type of the data is :" + obj.getClass().getName());
    }
    public T getObj()
    {
        return obj;
    }
}

public class generics3 {
    public static void main(String[] args) {

        Gen<Integer> g = new Gen<Integer>(10);

        g.display();
       System.out.println(g.getObj());

        // ArrayList<Gen> lis4 = new ArrayList<Gen>();
        // ArrayList<String> al = new ArrayList<String>();
        // List<String> li =  new ArrayList<String>();
        // Collection<Integer> col = new ArrayList<Integer>();
        // List<Integer> lis = new ArrayList<Integer>();

         //primitive data type is not added in the generics
        // List<int> lis2 = new ArrayList<int>();   

        //in generics both have same
        // List<Object> lis3 = new ArrayList<String>();

    }
}
