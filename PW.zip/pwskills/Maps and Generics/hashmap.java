import java.util.*;

public class hashmap
{
    public static void main(String[] args) {
        
        HashMap hm = new HashMap();
        hm.put(null, 5);
        hm.put(0, 0);
        hm.put(1, 1);
        hm.put(6, "Nikhil");
        hm.put(4, "RAKESH");
        hm.put(8, "Raj");
        hm.put(7, "RK");

        System.out.println(hm);

        LinkedHashMap lhm = new LinkedHashMap();
        lhm.put(0, "RAJ" );
        lhm.put(1,"Kumar" );
        lhm.put(5,"Shatrudhan" );
        lhm.put(2,"Lakshman" );
        lhm.put(3,"Sita" );
        lhm.put(4, "BHARAT");


        System.out.println(lhm);
    }
}