import java.util.Map.Entry;
import java.util.*;
import java.util.Map.*;


public class hashmap2 {
    private static Set entrySet;

    public static void main(String[] args) {
        
        HashMap hm = new HashMap();
        hm.put(11, "ram");
        hm.put(0, "bharat");
        hm.put(1, "tejas");
        hm.put(6, "Nikhil");
        hm.put(4, "RAKESH");
        hm.put(9, "Raj");
        hm.put(7, "RK");

        System.out.println(hm);

        System.out.println("----------------------");

        System.out.println( hm.get(7));    //to retrive the specific value
        System.out.println( hm.get(0));
       
        System.out.println("----------------------");

        Set keySet= hm.keySet();

        Iterator itr = keySet.iterator();  //to retrive all the keys
        while(itr.hasNext())
        {
          // System.out.println(itr.next());
           Integer in =(Integer)itr.next();
           System.out.println(in);
        }


        System.out.println("----------------------");


        Collection values = hm.values();  // to retrive all the values
        Iterator itr2 = values.iterator();
        while(itr2.hasNext())
        {
          // System.out.println(itr2.next());
          String name =(String)itr2.next();
          System.out.println(name);
        }


        System.out.println("----------------------");


        Set entrySet = hm.entrySet();  //to retrive both keys and values
        Iterator itr3 = entrySet.iterator();
        while(itr3.hasNext())
        {
          // System.out.println(it3.next());
          Map.Entry data=(Entry)itr3.next();

          System.out.println(data.getKey() + " : " + data.getValue());
          
        } 
    }
}