import java.util.*;
import java.util.Map.*;

class Employee
{
    private String name;
    private int empId ;

    public Employee(String name , int empId)
    {
        this.name=name;
        this.empId=empId;
    }

    public String tostring()
    {
        return empId + " ";
    }
}


public class hashmap4 {
    public static void main(String[] args) {
     
        Employee e = new Employee("NIkhil", 1);

    }
}
