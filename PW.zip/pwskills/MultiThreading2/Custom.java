class Mythread extends Thread
{

}

public class Custom {
    public static void main(String[] args) {
        
        MyThread mt = new 
    }
}
