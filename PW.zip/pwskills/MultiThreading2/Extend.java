class Non extends Thread{
    
    public void Run()
    {
        System.out.println("Inside Run Method");
        
    }

}

public class Extend {
    public static void main(String[] args) {

        System.out.println("Inside Main Method");

        Non n = new Non();
        n.start();
    }
}
