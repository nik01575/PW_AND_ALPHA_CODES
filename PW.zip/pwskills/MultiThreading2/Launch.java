class Mythreads extends Thread
{
    public void Run()
    {
        System.out.println("in Run Method");
    }
}

public class Launch
{
    public static void main(String[] args) {
        
        System.out.println("In Main Method");

        Mythreads mt = new Mythreads();
        mt.Run();
    }
}