import java.util.*;

class Text implements Runnable
{
    public void run()
    {
        System.out.println("Enter First Number");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        System.out.println("Enter Second Number");
        int b = sc.nextInt();
        int result = a + b;
        System.out.println("Your Result Is : " + result);

    }
}
class Demo{
    public void Main(){

    }
}
class Message extends Demo  implements Runnable 
{
    public void run()
    {
        for(int i=0; i<3; i++)
        {
            System.out.println("In Message ");
            
        }
    }
}

public class Launch3 {
    public static void main(String[] args) {
        
        Text tx = new Text();
        Message msg = new Message();

        Thread t1 = new Thread(tx);
        Thread t2 = new Thread(msg);

        t1.start();
        t2.start();
     
    }
}
