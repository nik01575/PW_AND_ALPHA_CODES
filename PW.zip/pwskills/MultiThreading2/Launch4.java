import java.util.*;

class MyThread extends Thread
{
    public void run()
    {
        String str = Thread.currentThread().getName();
        
        if(str.equals("CALC"))
        {
            calc();
        }
        else{
            impMessage();
        }
    }

    public void calc()
    {
        System.out.println("Second Task");

        try{
            for( int i = 0 ; i<7 ; i++)
            {
                System.out.println(i);
                Thread.sleep(2000);
            }
        }
        catch( Exception e)
        {
            System.out.println("Bhai Kuch Problem Hai" + e.getMessage());
        }
    }

    public void impMessage()
    {   
        System.out.println("First Task");

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter First Number");
        int a = sc.nextInt();

        System.out.println("Enter Second Number");
        int b = sc.nextInt();

        int result = a + b;
        System.out.println("Result Is:"  + result );
    }

   
}


public class Launch4 {
    public static void main(String[] args) {
        
        System.out.println("Main Method");

        MyThread thread1 = new MyThread();

        MyThread thread2 = new MyThread();

        thread1.setName("CALC");
        thread2.setName("Print");

        thread1.start();
        thread2.start();

    }
}
