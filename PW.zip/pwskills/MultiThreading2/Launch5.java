class MyThread implements Runnable
{
    public void run()
    {
        System.out.println("First Task");

        try{
            for( int i = 0 ; i<3 ; i++)
            {
                System.out.println("Succes is the Key");
                Thread.sleep(2000);
            }
        }
        catch( Exception e)
        {
            System.out.println("Bhai Kuch Problem Hai" + e.getMessage());
        }
    }
}

public class Launch5 {
    public static void main(String[] args) throws Exception
    {
        
        System.out.println("In Main Method");

        MyThread mt = new MyThread();
        Thread t = new Thread(mt);
        t.start();
        t.join();

        System.out.println("Bhai Kaam Khatm Ho Gya");
    }
}
