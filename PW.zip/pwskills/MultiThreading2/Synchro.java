class Details implements Runnable
{
    synchronized public void run() 
    {
        try
        {
            System.out.println(Thread.currentThread().getName() + "Enters In The Car");
            Thread.sleep(3000);

            System.out.println(Thread.currentThread().getName() + "Started In The Car");
            Thread.sleep(3000);
            System.out.println(Thread.currentThread().getName() + "Drives In The Car");
            Thread.sleep(3000);
            System.out.println(Thread.currentThread().getName() + "Parks In The Car");
            Thread.sleep(3000);

            // synchronized(this)
            //{
            // System.out.println(Thread.currentThread().getName() + "Started In The Car");
            // Thread.sleep(3000);
            // System.out.println(Thread.currentThread().getName() + "Drives In The Car");
            // Thread.sleep(3000);
            // System.out.println(Thread.currentThread().getName() + "Parks In The Car");
            // Thread.sleep(3000);
            // }
        }
        catch(Exception e)
        {
            System.out.println("Exception aa gya" + e.getMessage());
        }
    }

}

public class Synchro
{
    public static void main(String[] args) {
        
        Details dt = new Details();
        Thread t1 = new Thread(dt);
        Thread t2 = new Thread(dt);
        Thread t3 = new Thread(dt);

        t1.setName("Ram");
        t2.setName("Shyam");
        t3.setName("Mohan");

        t1.start();
        t2.start();
        t3.start();
    }
}