class New extends Thread
{
    System.out.print("In Thread");
}

public class ThreadExtends {
    public static void main(String[] args) {
        
        
        System.out.println();
    }
}
