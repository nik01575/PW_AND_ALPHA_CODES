import java.util.Scanner;

class MyThread extends Thread
{
    public void run()
    {
        Scanner sc = new Scanner (System.in);

        System.out.println("Enter Your Value");
        String s = sc.nextLine();
        System.out.println(" Your Value Is :  " + s );
    }
}

public class createthread {
    public static void main(String[] args) {

        System.out.println("Parent Class");
        MyThread t = new MyThread();
        t.start();
        System.out.println(  t.currentThread().getName());
    }
}
