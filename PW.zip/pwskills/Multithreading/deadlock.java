class Library implements Runnable
{
    String s1 = new String("Java");
    String s2 = new String("C++");
    String s3 = new String("Python");

    public void run()
    {
        String name = Thread.currentThread().getName();

        if(name.equals("Student1"))
        {
            try
            {
                Thread.sleep(3000);
                synchronized(s1)
                {
                    System.out.println("Student1 taken the book " + s1);
                    Thread.sleep(3000);
                    synchronized(s2)
                    {
                        System.out.println("Student1 taken the book " + s2);
                        Thread.sleep(3000);
                        synchronized(s3)
                        {
                            System.out.println("Student1 taken the book " + s3);
                            Thread.sleep(3000);
                        }
                    }
                }
            }
            catch(Exception e)
            {
                System.out.println("Bhai Problelm Hai");
            }

        }
        else
        {
            try
            {
                Thread.sleep(3000);
                synchronized(s3)
                {
                    System.out.println("Student2 taken the book " + s3);
                    Thread.sleep(3000);
                    synchronized(s2)
                    {
                        System.out.println("Student2 taken the book " + s2);
                        Thread.sleep(3000);
                        synchronized(s1)
                        {
                            System.out.println("Student2 taken the book " + s1);
                            Thread.sleep(3000);
                        }
                    }
                }
            }
            catch(Exception e)
            {
                System.out.println("Bhai Problelm Hai");
            }
        }
        
    }

}

public class deadlock {
    public static void main(String[] args) throws Exception
    {
        
        Library lib = new Library();

        Thread t1 = new Thread(lib);
        Thread t2 = new Thread(lib);

        t1.setName("Student1");
        t2.setName("Student2");

        t1.start();
        t2.start();

    }
}
