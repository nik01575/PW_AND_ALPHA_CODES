public class firstThread {
    public static void main(String[] args) {
        
        System.out.println("In the Main Method");
        String name = Thread.currentThread().getName();
        System.out.println(name);
        System.out.println(Thread.currentThread().getPriority());
        
    }
}
