public class multifirst 
{
    public static void main (String[] args)
    {
        System.out.println("Before Changing");
        String name = Thread.currentThread().getName();
        System.out.println(name);
        int prio = Thread.currentThread().getPriority();
        System.out.println(prio);
        System.out.println();

        Thread t = Thread.currentThread();
        t.setName("PW");
        t.setPriority(9);


        System.out.println("After Changing");
        String secname = Thread.currentThread().getName();
        System.out.println(secname);
        int priosec = Thread.currentThread().getPriority();
        System.out.println(priosec);
    }
}