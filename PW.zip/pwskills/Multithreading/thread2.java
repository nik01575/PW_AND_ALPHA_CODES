import java.util.Scanner;
class MyThread extends Thread
{
    public void run()
    {
        System.out.println("First Task");
        System.out.println("");

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter First Number");
        int a = sc.nextInt();

        System.out.println("Enter Second Number");
        int b = sc.nextInt();

        int result = a + b;
        System.out.println("Result Is:"  + result );


        System.out.println("");
    }
}
class Message extends Thread
{
    public void run()
    {
        System.out.println("Second Task");

        try{
            for( int i = 0 ; i<5 ; i++)
            {
                System.out.println(i);
                Thread.sleep(1000);
            }
        }
        catch( Exception e)
        {
            System.out.println("Bhai Kuch Problem Hai");
        }
       
    }
}


public class thread2 {
    public static void main(String[] args) {
        System.out.println("Main Method");

        MyThread m = new MyThread();
        m.start();
        System.out.println(m.currentThread().getName());

        Message me = new Message();
        me.start();
        System.out.println(me.currentThread().getName());
        
    }
}
