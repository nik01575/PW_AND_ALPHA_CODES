import java.util.Scanner;
class MyThread implements Runnable
{
    public void run()
    {
        System.out.println("First Task");
        System.out.println("");

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter First Number");
        int a = sc.nextInt();

        System.out.println("Enter Second Number");
        int b = sc.nextInt();

        int result = a + b;
        System.out.println("Result Is:"  + result );


        System.out.println("");
    }
}
class Message implements Runnable
{
    public void run()
    {
        System.out.println("Second Task");

        try{
            for( int i = 0 ; i<7 ; i++)
            {
                System.out.println(i);
                Thread.sleep(000);
            }
        }
        catch( Exception e)
        {
            System.out.println("Bhai Kuch Problem Hai" + e.getMessage());
        }
       
    }
}


public class thread3 {
    public static void main(String[] args) {
        System.out.println("Main Method");

        MyThread m = new MyThread();
        Message me = new Message();

        Thread t1 = new Thread(m);
        Thread t2 = new Thread(me);

        t1.start();
        t2.start();
        
    }
}
