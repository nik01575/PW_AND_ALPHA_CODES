import java.util.Scanner;

class MyThread extends Thread
{

    public void run()
    {
        String name = Thread.currentThread().getName();
        
        if(name.equals("CALC"))
        {
            calc();
        }
        else
        {
            getmessage();
        }
    }
    public void calc ()
    {
        System.out.println("First Task");

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter First Number");
        int a = sc.nextInt();

        System.out.println("Enter Second Number");
        int b = sc.nextInt();

        int result = a + b;
        System.out.println("Result Is:"  + result );

    }

    public void getmessage()
    {
        System.out.println("Second Task");

        try{
            for( int i = 0 ; i<7 ; i++)
            {
                System.out.println(i);
                Thread.sleep(2000);
            }
        }
        catch( Exception e)
        {
            System.out.println("Bhai Kuch Problem Hai" + e.getMessage());
        }
    }
}


public class thread4 {
    public static void main(String[] args) {
        System.out.println("Main Method");

        MyThread thread1 = new MyThread();

        MyThread thread2 = new MyThread();

        thread1.setName("CALC");
        thread2.setName("Print");

        thread1.start();
        thread2.start();
        
    }
}
