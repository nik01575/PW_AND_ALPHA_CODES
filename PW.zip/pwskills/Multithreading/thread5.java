class MyThread implements Runnable
{
    public void run()
    {
        try{
            for( int i = 0 ; i<7 ; i++)
            {
                System.out.println("Hello");
                Thread.sleep(2000);
            }
        }
        catch( Exception e)
        {
            System.out.println("Bhai Kuch Problem Hai" + e.getMessage());
        }
    }
}

public class thread5 {
    public static void main(String[] args) throws Exception
    {
        System.out.println("Main Thread Started");
        MyThread m1 = new MyThread();

        Thread t1 = new Thread(m1);
        System.out.println(t1.isAlive());

        t1.start();
        System.out.println(t1.isAlive());
        t1.join();

        System.out.println("Code Finished");

    }
}
