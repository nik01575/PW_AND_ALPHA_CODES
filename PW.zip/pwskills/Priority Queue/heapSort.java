public class heapSort {

    public static void swap(int arr[] , int i , int j)
    {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
    public static void printArr(int arr[] , int n)
    {
        for(int i=0; i<n; i++)
        {
            System.out.println(arr[i] + " ");
        }
        System.out.println();
    }

    public static void heapify(int arr[] ,int n , int i )
    {
        //initialise larger as root
        int larger =i;
        int l = 2*i+1;
        int r = 2*i+2;

        //if left child is larger than the root
        if(l<n && arr[l] > arr[larger])
        {
            larger = l;
        }

        //if right child is larger than the root
        if(r<n && arr[r] > arr[larger])
        {
            larger = r;
        }
        //if largest is the root
        if(larger != i)
        {
            swap(arr, i, larger);
            heapify(arr, n, larger);
        }

    }

    public static void sort(int arr[] , int n)
    {
        for(int i = (n/2)-1 ; i>=0; i--)
        {
            heapify(arr, n, i);
        }

        for(int i=n-1; i>0; i--)
        {
            swap(arr, i, 0);
            heapify(arr, i, 0);
        }
    }
    public static void main(String[] args) {
        
        int arr[] = {13 , 11 , 7 , 12 , 5};
        
        sort(arr, arr.length);
        printArr(arr, arr.length);
    }
}