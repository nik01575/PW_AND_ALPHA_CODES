// Brute Force


public class FindingPower {
    public static long Power(long n , long m)
    {
        if(m==1)
        {
            return n;
        }
        return n * Power(n, m-1);
    }
    public static void main(String[] args) {
        System.out.println( Power(2 , 32));
       
    }
}
