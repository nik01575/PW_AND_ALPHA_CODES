public class FindingPower2 {
    public static long Power(long n, long m) {
        if (m == 1) {
            return n;
        }

        long mid = m / 2;
        long result = Power(n, mid);
        long finalresult = result * result;

        if (m % 2 == 0) {
            return finalresult;
        } else {
            return n * finalresult;
        }
    }

    public static void main(String[] args) {
        System.out.println(Power(2, 32));

    }
}
