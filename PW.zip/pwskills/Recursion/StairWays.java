public class StairWays {

    public static int Ways(int n)
    {
        if(n==0 || n==1)
        {
            return n;
        }
        return Ways(n-2) + Ways(n-1);
    }
    public static void main(String[] args) {
        // 1 2 3 5 8 13 21
        int n =4;
        int result = Ways(n+1);
        System.out.println("Number of Ways are : " + result);
        
    }
}
