
public class TwoDMatrixSearch {

    public static boolean search(int arr[][]) {

        // no of rows
        int m = arr.length;
        if (m == 0) {
            return false;
        }
        // no of columns
        int n = arr[0].length;

        int target = 30;
        int low = 0;
        int high = m * n - 1;

        while (low <= high) {
            int midIndex = low + (high - low) / 2;
            int midElement = arr[midIndex / n][midIndex % n];

            if (midElement == target) {
                return true;
            } else {
                if (target<midElement) {
                    high = midIndex - 1;
                } else {
                    low = midIndex +1;
                }
            }

        }
        return false;
    }

    public static void main(String[] args) {

        int arr[][] = { { 1, 3, 5, 7 },
                { 10, 11, 16, 20 },
                { 23, 30, 34, 60 } };

        System.out.println(search(arr));

    }
}
