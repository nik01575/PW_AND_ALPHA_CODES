
public class alternatesum {

    public static int alternatesum1(int n)
    {
        if(n==0)
        {
            return 0;
        }
        else if(n%2==0)
        {
            return alternatesum1(n-1) - (n);
        }
        else
        {
            return alternatesum1(n-1) + n;
        }
    }
    public static void main(String[] args) {
        System.out.println(alternatesum1(5));
     
    }
}
