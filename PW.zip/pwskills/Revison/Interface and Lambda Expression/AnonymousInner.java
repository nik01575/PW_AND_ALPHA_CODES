interface Car
{
    void drive();
}

// class Maruti implements Car
// {
//     public void drive()
//     {
//         System.out.println("Maruti is Car");
//     }
// }

public class AnonymousInner {
    public static void main(String[] args) {
        // Car obj = new Maruti();

        Car obj = new Car()
        {
            public void drive()
            {
              System.out.println("Maruti is Car");
            }
        };
        obj.drive();
    }
}
