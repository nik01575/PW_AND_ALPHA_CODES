// inner class - member , static , anonymous

class A
{
    public void show()
    {
        System.out.println("in class A show method");
    }
    static class B
    {
        public void display()
        {
            System.out.println("in class A->B display method");
        }
    }
}

public class InnerClass {
    public static void main(String[] args) {
        A obj = new A();
        obj.show();

        // A.B obj1 = obj.new B();      ------------> If inner class is public
         A.B obj1 = new  A.B();       //------------> If inner class is static
        obj1.display();

        
    }
}
