
interface A
{
    void show();
    default void config()
    {
        System.out.println("in config");
    }
    static void display()
    {
        System.out.println("in display");
    }
}

class B implements A
{
    public void show()
    {
        System.out.println("in show");
    }
    // public void display()
    // {
    //     System.out.println("In class B display");
    // }
}

public class Java8Features {
    public static void main(String[] args) {
        A.display();
        
        A obj = new B();
        obj.show();
        obj.config();
        // obj.display();

    }
}
