interface Computer
{
    public abstract void compileCode();
}

class Laptop implements Computer
{
    public void compileCode() 
    {
        System.out.println("Your got 5 errors");
    }
}
class Desktop implements Computer
{
    public void compileCode()
    {
        System.out.println("You are faster but you got errors");
    }
}

class Developer
{
    public static void buildApp(Computer obj)
    {
        System.out.println("Building App");
        obj.compileCode();
    }
}

public class basic
{
    public static void main(String[] args) {
        Laptop lap = new Laptop();
        Desktop dek = new Desktop();

        Developer dev = new Developer();
        dev.buildApp(dek);
    }
}