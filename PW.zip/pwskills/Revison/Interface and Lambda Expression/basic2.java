interface A
{
    void show();
}
interface X
{
    void abc();
}

class B implements A , X
{
    public void show()
    {
        System.out.println("in show");
    }
    public void abc()
    {
        
    }
}

public class basic2 {
    public static void main(String[] args) {
        B b = new B();
        b.show();
    }
}
