public class PrintSSQ {

    static void printSSQ(String s , String currAns)
    {
        if(s.length() == 0)
        {
            System.out.println(currAns);
            return;
        }
        char curr = s.charAt(0);
        String remString = s.substring(1);

        //curr char - chooses to be a part of currAns
        printSSQ(remString, currAns + curr);
        //curr char - doesn't chooses to be a part of currAns
        printSSQ(remString, currAns);
    }
    public static void main(String[] args) {
        printSSQ("abc", " ");
    }
}
