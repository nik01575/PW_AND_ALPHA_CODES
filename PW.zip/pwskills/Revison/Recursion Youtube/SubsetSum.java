public class SubsetSum {

    static void subset(int [] arr , int sum , int indx , int n)
    {
        if(indx >= n)
        {
            System.out.println(sum);
            return;
        }
        //curr indx + sum
        subset(arr, sum + arr[indx], indx+1, n);
        //curr indx
        subset(arr, sum , indx+1, n);
    }
    public static void main(String[] args) {
        
        int [] arr = {2 , 4, 5};
        subset(arr, 0, 0, arr.length);
    }
}
