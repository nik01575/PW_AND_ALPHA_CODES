public class digitSum {

    public static int sum(int n)
    {

        if(n >= 0 && n <= 9)
        {
            return n;
        }
        
        return sum(n/10) + n%10;
    }
    public static void main(String[] args) {
        int n = 5683;

        System.out.println(sum(n));
        // System.out.println(n%10); // 4
        // System.out.println(n/10); //123

    }
}
