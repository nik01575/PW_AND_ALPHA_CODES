public class distanceCost {

    public static int cost(int n , int[] h , int indx)
    {
        if(indx == n-1)
        {
            return 0;
        }
        int op1 = Math.abs(h[indx] - h[indx+1]) + cost(n, h, indx+1);

        if(indx == n-2)
        {
            return op1;
        }
        int op2 = Math.abs(h[indx] - h[indx+2]) + cost(n, h, indx+2);

        return Math.min(op1, op2);
    }
    public static void main(String[] args) {
        int arr[] = {10 , 30 , 40 , 20};

        System.out.println(cost(arr.length, arr , 0));
    }
}
