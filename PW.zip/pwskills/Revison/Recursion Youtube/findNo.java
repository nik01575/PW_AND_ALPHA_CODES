public class findNo {
    public static int find(int n)
    {

        if(n >= 0 && n <= 9)
        {
            return 1;
        }

        return find(n/10) +1;
        
    }
    public static void main(String[] args) {
        System.out.println(find(588));
    }
}
