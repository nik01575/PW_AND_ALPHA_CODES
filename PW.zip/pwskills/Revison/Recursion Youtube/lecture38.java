import java.util.*;
public class lecture38 {

    static String remove(String s)
    {
        if(s.length() == 0)
        {
            return " ";
        }

        String ans = remove(s.substring(1));
        
        char curr = s.charAt(0);

        //self work
        if(curr != 'a')
        {
            return curr+ans;
        }else{
            return ans;
        } 
    }

    static String removeA(String s , int indx)
    {
        //base case
        if(indx == s.length())
        {
            return " ";
        }

        //recursive work
        String ans = removeA(s, indx+1);

        char curr = s.charAt(indx);

        //self work
        if(curr != 'a')
        {
            return curr+ans;
        }else{
            return ans;
        }
    }
    public static void main(String[] args) {
        
        System.out.println("Enter Your String");
        Scanner sc = new Scanner(System.in);
        String st = sc.nextLine();
        // System.out.println("Your String is " + st);

        // System.out.println(removeA(st, 0));
        System.out.println(remove(st.substring(1)));
    }
}
