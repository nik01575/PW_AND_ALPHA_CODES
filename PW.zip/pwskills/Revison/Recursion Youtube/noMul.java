public class noMul {

    public static void mul(int n,int k)
    {
        if(k == 0)
        {
            // System.out.println(n);
            return;
        }

        mul(n, k-1);
        System.out.println(n*k);
    }
    public static void main(String[] args) {
        
        mul(5, 4);
    }
}
