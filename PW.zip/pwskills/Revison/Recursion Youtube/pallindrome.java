public class pallindrome
{
    // static String reverse(String s , int indx)
    // {
    //     if(indx == s.length())
    //     {
    //         return "";
    //     }
    //     String smallans = reverse(s, indx+1);
    //     return smallans + s.charAt(indx);
    // }

    static boolean isPalindrome(String s , int l , int r)
    {
        if(l>=r)
        {
            return true;
        }
        return (s.charAt(l) == s.charAt(r) && isPalindrome(s, l+1, r-1));
    }
    public static void main(String[] args) {
        
        String s = "level";
        // String rev = reverse(s, 0);

        // if(rev.equals(s))
        // {
        //     System.out.println("pallindrome");
        // }else{
        //     System.out.println("Not a pallindrome");
        // }

        System.out.println(isPalindrome(s, 0, s.length()-1));
    }
}