public class printFibonacci {

  

    // public static int print(int n)
    // {
    // if (n <= 1)
    // return n;

    // // Recursive call
    // return print(n - 1) + print(n - 2);
    // }
    // public static void main(String[] args) {

    // int n=15;

    // // Print the first N numbers
    // for (int i = 0; i < n; i++) {

    // System.out.print(print(i) + " ");
    // }
    // }
}
