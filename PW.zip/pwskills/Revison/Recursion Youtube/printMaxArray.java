public class printMaxArray {

    public static int printArray(int arr[] , int idx )
    {
        if(idx == arr.length-1)
        {
            return arr[idx];
        }

        int samllAns = printArray(arr, idx+1);

        return Math.max(arr[idx], samllAns);
        
    }
    public static void main(String[] args) {
        int arr[] = { 5 , 16 , 17 , 8 , 9};
        System.out.println(printArray(arr, 0));
    }
}
