public class product {
    // public static int total(int x , int y)
    // {
    // if(y == 0)
    // {
    // return 1;
    // }
    // return x * total(x, y-1) ;
    // }

    public static int total(int x, int y) {
        if (y == 0) {
            return 1;
        }
        int pow = total(x, y / 2);

        if (y % 2 == 0) {
            return pow * pow;
        }
        return x * pow * pow;

    }

    public static void main(String[] args) {

        System.out.println(total(2, 4));
    }
}
