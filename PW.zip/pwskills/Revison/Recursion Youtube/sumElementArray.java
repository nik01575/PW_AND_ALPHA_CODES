public class sumElementArray {

    public static int printArray(int arr[] , int idx )
    {
        if(idx == arr.length)
        {
            return 0;
        }

        int ans =printArray(arr, idx+1);

        return ans+arr[idx];
    }
    public static void main(String[] args) {
        int arr[] = { 1, 2 , 3 , 4 , 10};
        System.out.println(printArray(arr, 0));
    }
}
