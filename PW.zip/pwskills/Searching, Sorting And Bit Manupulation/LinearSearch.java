import java.util.*;

public class LinearSearch
{
    public static int Search(int arr[] , int key)
    {
        for(int i=0; i<arr.length; i++)
        {
            if(arr[i] == key)
            {
                return i;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        int arr[] = { 2 , 4 , 16 , 8, 12 , 34};
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the searching element");
        int key = sc.nextInt();

        System.out.println("Your Element is Preset at : " + Search(arr, key));
    }
}