import java.util.Arrays;

public class SelectionSort {

    public static void sorting(int arr[]) {

        for (int i = 0; i < arr.length - 1; i++) {
            int min_indx = i;

            for (int j = i + 1; j < arr.length; j++) {

                if (arr[j] < arr[min_indx]) {
                    min_indx = j;
                }
            }
            if (min_indx != i) {
                // swap
                int temp = arr[i];
                arr[i] = arr[min_indx];
                arr[min_indx] = temp;
            }
        }

    }

    public static void main(String[] args) {
        int arr[] = { 20, 30, 12, 50, 70, 100, 90, 105, 75 };
        sorting(arr);

        System.out.println(Arrays.toString(arr));
    }
}
