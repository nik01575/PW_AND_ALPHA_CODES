import java.util.*;

public class Squareroot {

    public static int Sqrt(int key) {
        int start = 0;
        int end = key;
        int result = -1;

        while (start <= end) {
            int mid = start + (end - start) / 2;
            long val = mid * mid;

            if (val == key) {
                // perfect square
                return mid;
            } else if (val < key) {
                result = mid;
                start = mid + 1;
            } else {
                end = mid - 1;
            }
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the searching element");
        int key = sc.nextInt();

        int result = Sqrt(key);
        System.out.println("Square Root is : " + result);
        sc.close();
    }
}
