public class duplicate {
   public static void main(String argu[]) {
      String str = "PW SKILLS";
      char[] array = str.toCharArray();

      System.out.println("The string is:" + str);
      System.out.print("Duplicate Characters in above string are: ");

      for (int i = 0; i < str.length(); i++) {
         for (int j = i + 1; j < str.length(); j++) {
            if (array[i] == array[j]) {
               System.out.print(array[j] + " ");
               break;
            }
         }
      }

   }
}