public class StringConcatenation
{
    public static void main(String[] args) {
        String a = "Sachine";
        int b=10;
        int c=20;
        int d=30;

        System.out.println(a+b+c+d);
        System.out.println(b+c+d+a);
        System.out.println(b+c+a+d);
        System.out.println(b+a+c+d);

    }
}