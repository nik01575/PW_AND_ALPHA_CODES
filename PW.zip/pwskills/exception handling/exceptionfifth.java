class MyException extends Exception
{

}

public class exceptionfifth {
    public static void main(String[] args)
    {
        int a = 6;
        int b = 0;
        int result = 0;

        try 
        {
            if( b < 0 || a < 0)
            {
                Exception e = new MyException();
                throw e;
            }
            else{
                result = a/b ;
                System.out.println("Total Value Is : " + result);
            }

        }
        catch ( Exception e)
        {
            System.out.println("Bro Error AA Gya : " + e);
        }
    }
}
