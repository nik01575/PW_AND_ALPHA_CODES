public class exceptionfirst
{
    public static void main(String[] args)   
    {
        int a=6;
        int b= 0;
       int result = 0;
        try 
        {
           result= a/b;
        }
        catch (Exception obj)
        {
            System.out.println("Something went wrong");
        }

        System.out.println(result);
        System.out.println("bye");
    }
}