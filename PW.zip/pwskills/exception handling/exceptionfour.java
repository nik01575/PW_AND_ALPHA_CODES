class Demo
{
    public void a() throws Exception
    {
        b();

        //  try{
        //     b();
        // }
        // catch(Exception e)
        // {
        //     System.out.println("Bro Error Aaa gya : "  + e.getMessage());
        // }
        
    }
    public void b() throws Exception
    {
        int first = 6;
        int second = 0;
        int result = 0;

        result = first / second;
        System.out.println("Final Result Is : "  +  result);


        // try{
        //     result = first / second;
        //     System.out.println("Final Result Is : "  +  result);
        // }
        // catch(Exception e)
        // {
        //     System.out.println("Bro Error Aaa gya : "  + e.getMessage());
        // }
        
    }
}

public class exceptionfour {
    public static void main(String[] args)
    {
        Demo d = new Demo();
        

         try{
            d.a();
        }
        catch(Exception e)
        {
            System.out.println("Bro Error Aaa gya : "  + e.getMessage());
        }
    }
}
