public class exceptionsecond
{
    public static void main(String[] args)   
    {
        int a=6;
        int b= 2;
        int result = 0;
        int values[] = {4,7,2,9};
        String name = null;
        int last =0;

        try 
        {
           result= a/b;
           System.out.println(values[2]);
           last = a/name.length();
           
        }
        catch (ArithmeticException obj)
        {
            System.out.println("Something went wrong + + " + obj);
        }
        catch (ArrayIndexOutOfBoundsException obj)
        {
            System.out.println("Out of Limits + + " + obj);
        }
        catch( Exception obj)
        {
            System.out.println(" All Exceptions + +  " + obj);
        }
        
        System.out.println(result);
        System.out.println("bye");
    }
} 
    
