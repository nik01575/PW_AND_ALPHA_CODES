import java.util.InputMismatchException;
import java.util.Scanner;

public class exceptionthird {
    public static void main(String[] args)
    {
        int name = 0;

        // try(Scanner sc = new Scanner(System.in))
        // {
        //     name = sc.nextInt();
        // }

        Scanner sc = new Scanner(System.in);

        try 
        {
            name = sc.nextInt();
        }

        catch( InputMismatchException e)
        {
            System.out.println("Error : " + e);
        }

        finally
        {
            sc.close();
            System.out.println("Resource Closed");
        }
        
        System.out.println("Your Value Is : " + name);

    }
}
