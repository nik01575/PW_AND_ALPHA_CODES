public class pangram
{
    public static void main(String[] args)
    {
        String s = "Hello World";

             int i = s.indexOf('o');

             int j = s.lastIndexOf('l');

             System.out.print(i + " " + j);
    }
}