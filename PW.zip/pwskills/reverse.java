import java.util.Scanner;
public class reverse
{
    public static void main(String[] args)
    {
        // System.out.println("Enter Your String");
        // Scanner sc= new Scanner(System.in);
        // String s1=sc.next();
        String s1="PWSKILLS";
        String s2=" ";
        for ( int i=s1.length()-1 ; i>=0; i--)
        {
            s2= s2+s1.charAt(i);
        }
        System.out.println("Before Reversing :" + s1);
        System.out.println("After Reversing:"+ s2);
    }
}