import java.util.Scanner;
public class reverse2
{
    public static void main(String[] args)
    {
        // System.out.println("Enter Your String");
        // Scanner sc= new Scanner(System.in);
        // String s1=sc.next();
        String s1="PW SKILL";
        String s2=" ";

        String arr[]= s1.split(" ");
        for ( int i=arr.length-1 ; i>=0; i--)
        {
            s2= s2+arr[i] + " ";
        }
        System.out.println("Before Reversing :" + s1);
        System.out.println("After Reversing:"+ s2);
    }
}