public class reverse4
{
    public static void main(String[] args)
    {
        String s1="Think Twice";
        String s2="";

         
          String arr[]= s1.split(" ");

        for( String ele:arr)
        {
            for ( int i=ele.length()-1 ; i>=0; i--)
            {
            s2= s2+ele.charAt(i);
            }
            s2=s2+" ";
        }
        // s2=s2.toLowerCase();

        System.out.println("Before Reversing :" + s1);
        System.out.println("After Reversing: "+ s2);
    }
}