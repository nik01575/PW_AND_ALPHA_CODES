public class temp {
    public static void main(String[] args) {
        int x = -121;

        System.out.println(x/100);
        System.out.println(x%10);
    }
}
